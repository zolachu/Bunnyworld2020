package edu.stanford.cs108.bunnyworld;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import android.content.Context;
import android.graphics.Canvas;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class Game {
    private int id;
    private String name;
    private int startPageIndex;
    private List<Page> pages;
    private List<Shape> inventory;

    Game(int id, String name, List<Page> pages) {
        this.id = id;
        this.name = name;
        this.pages = pages;
        this.inventory = new ArrayList<>();
        this.startPageIndex = 0;
    }

    Game(int id, String name) {
        this(id, name, new ArrayList<>(Collections.singletonList(new Page())));
    }

    void addInventoryItem(Shape item) {
        if (item == null || inventory.contains(item)) return;

        inventory.add(item);
    }

    void addPage(Page page) {
        if (page == null || pages.contains(page)) return;

        pages.add(page);
    }

    /**
     * Draws inventory shapes on given canvas.
     * Note: Hidden inventory items are not drawn.
     * @param canvas game play canvas
     * @param context current activity
     */
    void drawInventory(Canvas canvas, Context context) {
        for (Shape item : inventory) {
            if (!item.getHidden()) item.draw(canvas, context);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Game game = (Game) o;
        return name.equalsIgnoreCase(game.name);
    }

    public List<Shape> getAllShapes() {
        List<Shape> allShapes = new ArrayList<>();
        for(Page page : pages) {
            allShapes.addAll(page.getShapes());
        }
        allShapes.addAll(inventory);

        return allShapes;
    }

    public int getId() { return id; }

    public Shape getInventoryItemAt(float x, float y) {
        if (inventory == null || inventory.isEmpty()) return null;

        for (int i = inventory.size() - 1; i >= 0; i--) {
            Shape item = inventory.get(i);
            if (item.insideShape(x, y)) return item;
        }

        return null;
    }

    public boolean inPossession(String shapeName) {
        boolean inside = false;
        for(Shape shape : inventory) {
            if(shape.getName().equalsIgnoreCase(shapeName)) {
                inside = true;
                break;
            }
        }
        return inside;
    }

    public String getName() {
        return name;
    }

    public int getNumPages() {
        return pages.size();
    }

    List<Page> getPages() {
        return pages;
    }

    public Page getPageByName(String name) {
        for (Page page : pages) {
            if (page.getName().equalsIgnoreCase(name)) return page;
        }

        return null;
    }

    public Set<String> getPageNames() {
        return pages.stream().map(Page::toString).collect(Collectors.toSet());
    }

    public Set<String> getShapeNames() {
        return getAllShapes().stream().map(Shape::toString).collect(Collectors.toSet());
    }

    public Page getStartPage() {
        if (pages.isEmpty()) return null;

        return pages.get(startPageIndex);
    }

    /**
     * Highlight inventory items with corresponding onDrop action for given shape
     * @param selectedShape
     */
    public void highlightInventoryItemsWithOnDrop(Shape selectedShape) {
        if (selectedShape == null) return;

        for (Shape item : inventory) {
            if (item.inOnDrop(selectedShape.getName()) && item.getSelectable()) {
                item.setHovered(true);
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public boolean hasPageName(String name) {
        return getPageNames().contains(name);
    }

    public boolean hasShapeName(String name) {
        return getShapeNames().contains(name);
    }

    /**
     * Returns true if the game inventory, associated pages, shapes, and shape scripts are all valid.
     * This could be an expensive operation for a large game with many pages and shapes, or complex
     * shape scripts - do try to call it where a delay is less likely to impact visual performance.
     * @return true if game and associated data structures are valid, else false
     */
    public boolean isValid() {
        List<Shape> shapeList = getAllShapes();
        if (getPageNames().size() != pages.size() || getShapeNames().size() != shapeList.size()) {
            return false;
        }

        for (Shape shape : shapeList) {
            shape.refreshScripts();
            if (!shape.hasValidScriptActions(this) || !shape.hasValidImageName()) return false;
        }

        return true;
    }

    public void removeInventoryItem(Shape item) {
        if (item == null || !inventory.contains(item)) return;

        inventory.remove(item);
    }

    public void removePage(Page page) {
        if (page == null || !pages.contains(page)) return;

        pages.remove(page);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShapesHovered(boolean choice) {
        for (Shape item : inventory) {
            item.setHovered(choice);
        }
    }

    public void setStartPage(Page page) {
        if (pages.isEmpty() || !pages.contains(page)) return;

        startPageIndex = pages.indexOf(page);
    }

    @Override
    public String toString() {
        return this.getName();
    }

    public String toJSON() {
        GsonBuilder gsonBuilder = new GsonBuilder().serializeNulls();
        Gson gsonCreator = gsonBuilder.create();
        return gsonCreator.toJson(this);
    }

    public static Game JSONtoGame(int newId, String JSONstring) {
        Game game = JSONtoGame(JSONstring);
        game.id = newId;
        return game;
    }


    public static Game JSONtoGame(String JSONstring) throws InvalidParameterException {
        Gson gsonBuilder = new GsonBuilder().create();

        Game currentGame = gsonBuilder.fromJson(JSONstring, Game.class);
        currentGame.pages = new ArrayList<>();

        JsonElement jsonTree = JsonParser.parseString(JSONstring);

        if (jsonTree.isJsonObject()){
            JsonObject jsonObject = jsonTree.getAsJsonObject();
            JsonElement pageElem = jsonObject.get("pages");

            if (pageElem.isJsonArray()){
                JsonArray pageArray = pageElem.getAsJsonArray();

                for (int i = 0; i < pageArray.size(); i++) {
                    if (pageArray.get(i).isJsonObject()) {
                        JsonObject newPage = pageArray.get(i).getAsJsonObject();
                        Page page = Page.JSONtoPage(newPage.toString());

                        currentGame.addPage(page);
                    }
                }
            }
        } else {
            throw new InvalidParameterException("The format of the string isn't in a valid JSON format");
        }
        return currentGame;
    }

    public boolean isUniquePageName(String name) {
        if (name == null) return false;

        for (Page page : pages) {
            if (page.getName().equalsIgnoreCase(name)) return false;
        }

        return true;
    }

    public boolean isUniqueShapeName(String name) {
        if (name == null) return false;

        for (Shape shape : getAllShapes()) {
            if (shape.getName().equalsIgnoreCase(name)) return false;
        }

        return true;
    }

    public Shape getShapeByName(String name) {
        for (Shape shape : getAllShapes()) {
            if (shape.getName().equalsIgnoreCase(name)) return shape;
        }

        return null;
    }

    public void onClickShape(Shape shape, Context context) {
        shape.onClick(this, context);
    }

    public int getNumInventoryItems() {
        return inventory.size();
    }


}
