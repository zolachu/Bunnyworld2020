package edu.stanford.cs108.bunnyworld;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

// Semi-pseudocode
public class LSystem {
    // Canvas
    Canvas curr_canvas;
    Paint curr_paint;
    // Turtle
    double x;
    double y;
    double step;
    double curr_angle;
    double delta_angle;
    // Stacks to hold previous values
    Stack<Double> x_stack = new Stack<>();
    Stack<Double> y_stack = new Stack<>();
    Stack<Double> angle_stack = new Stack<>();

    // L-System
    String the_string;
    int num_iter;
    // Grammar
    // F/G -> Draw forward

    // X -> Change curve - only used to build ruleset
    // Y -> Change curve - only used to build ruleset

    // - -> Turn left
    // + -> Turn right

    // [ -> Save current position
    // ] -> Restore previous position

    // The Rules
    public ArrayList<String[]> rules = new ArrayList<>();
    // Rules to define:
    String[] ruleF = {"F", ""}; // index 0
    String[] ruleG = {"G", ""}; // 1
    String[] ruleX = {"X", ""}; // 2
    String[] ruleY = {"Y", ""}; // 3



    // Instructions to implement - MAYBE MAKE ARRAY LIST
    ArrayList<Instruction> instructions = new ArrayList<>();

    public LSystem(){

    }

    public void setUpSystem(){
        addRules();
        // Build out the ruleset
        for (int i = 0; i < num_iter; i++){
            the_string = buildRules(the_string);
        }
        // Fill out the instructions
        for (int i = 0; i < the_string.length(); i++){
            findInstruction(the_string.charAt(i));
        }
    }

    public void addRules(){
        rules.add(ruleF);
        rules.add(ruleG);
        rules.add(ruleX);
        rules.add(ruleY);
    }

    public void setAxiom(String string_init){
        the_string = string_init;
    }

    // Attach a transformation/ruleset to a rule
    public void setRule(Character rule, String ruleset){
        switch (rule){
            case 'F':
                Array.set(ruleF, 1, ruleset);
                break;
            case 'G':
                Array.set(ruleG, 1, ruleset);
                break;
            case 'X':
                Array.set(ruleX, 1, ruleset);
                break;
            case 'Y':
                Array.set(ruleY, 1, ruleset);
                break;
            default:
                break;
        }
    }

    public void setValues(double step_init, double x_init, double y_init, double angle_init, double delta_init, int iter_init){
        step = step_init;
        x = x_init;
        y = y_init;
        curr_angle = angle_init;
        delta_angle = delta_init;
        num_iter = iter_init;
    }


    public void setCanvas(Canvas canvas){
        curr_canvas = canvas;
    }

    public void setPaint(int color){
        curr_paint = new Paint();
        curr_paint.setColor(color);
        curr_paint.setStyle(Paint.Style.STROKE);
        curr_paint.setStrokeWidth(5.0f);
    }

    private String buildRules(String s) {
        StringBuilder out = new StringBuilder();

        // Loop through string looking for rules
        for (int i = 0; i < s.length(); i++) {
            boolean match = false;
            // Loop through rules
            for (int j = 0; j < rules.size(); j++){
                String[] test = rules.get(j);
                // Check for matching char
                if (s.charAt(i) == test[0].charAt(0)){
                    String[] add = rules.get(j);
                    out.append(add[1]);
                    match = true;
                    break;
                }
            }
            if (!match){
                out.append(s.charAt(i));
            }
        }
        // Return action string
        return out.toString();
    }

    private void findInstruction(Character k){
        switch (k){
            case 'F':
                // Store draw instruction
                Draw new_draw1 = new Draw();
                instructions.add(new_draw1);
                break;
            case 'G':
                // Store draw instruction
                Draw new_draw2 = new Draw();
                instructions.add(new_draw2);
                break;
            case '[':
                Store new_store = new Store();
                instructions.add(new_store);
                break;
            case ']':
                Retrieve new_retrieve = new Retrieve();
                instructions.add(new_retrieve);
                break;
            case '-':
                Minus new_minus = new Minus();
                instructions.add(new_minus);
                break;
            case '+':
                Plus new_plus = new Plus();
                instructions.add(new_plus);
                break;
            default:
                break;
        }

    }

    public void runInstructions(){
        for (Instruction instr : instructions){
            //System.out.println("Instruction running...");
            instr.exec();
        }
    }

    private interface Instruction{
        void exec();
    }
    // Draw the curve - should usually be the same - mb just one class?
    private class Draw implements Instruction {
        // Handles drawing
        public void exec(){
            // Calculate new x, y, etc
            double x1 = x + step*Math.cos(Math.toRadians((curr_angle)));
            double y1 = y + step*Math.sin(Math.toRadians(curr_angle));
//            System.out.println(x1);
//            System.out.println(y1);
            // Draw forward
            curr_canvas.drawLine((float)x, (float)y, (float)x1, (float)y1, curr_paint);
            // Update x and y
            x = x1;
            y = y1;
        }
    }

    // TODO - figure out what's wrong here
    private class Plus implements Instruction{
        public void exec(){
            curr_angle += delta_angle;
        }
    }
    private class Minus implements Instruction{
        public void exec(){
            curr_angle -= delta_angle;
        }
    }
    // Instructions to store/retrieve position
    private class Store implements Instruction{
        // Push x, y, angle to stack
        public void exec(){
            x_stack.push(x);
            y_stack.push(y);
            angle_stack.push(curr_angle);
        }
    }
    private class Retrieve implements Instruction{
        // Pop x, y, curr_angle off stack
        public void exec(){
            x = x_stack.pop();
            y = y_stack.pop();
            curr_angle = angle_stack.pop();
        }
    }
} // END L-System
