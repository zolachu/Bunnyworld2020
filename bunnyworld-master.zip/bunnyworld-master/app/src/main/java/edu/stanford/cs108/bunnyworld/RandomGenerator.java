package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class RandomGenerator extends AppCompatActivity {
    LSystem system;
    Spinner dropdown;
    ResourceList resources = ResourceList.getInstance();
    DrawingView draw_view;
    boolean replace = false;
    int replace_color;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_generator);

        draw_view = findViewById(R.id.drawing_view);

        dropdown = findViewById(R.id.select_system);
        // Create adapter from the color list
        ArrayAdapter<CharSequence> choose_adapter = ArrayAdapter.createFromResource(this, R.array.lsystem_array, android.R.layout.simple_spinner_item);
        choose_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the spinners adapter to the previously created one.
        dropdown.setAdapter(choose_adapter);
        //system = new LSystem();


        Button save_button = findViewById(R.id.rand_save_button);
        save_button.setOnClickListener((view) -> saveDialog(null));
    }

    public void generateSystem(View view){
        String sys_name = dropdown.getSelectedItem().toString();
        DrawingView draw_view = findViewById(R.id.drawing_view);
        draw_view.buildSystem(sys_name);
        draw_view.drawSystem();
    }

    public void chooseSystemColor(View view){
        final View layout = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose New Color");
        builder.setCancelable(true);
        builder.setView(layout);

        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton("Choose", (dialog, which) -> {});
        builder.setNeutralButton("Try Color", (dialog, which) -> {});
        final AlertDialog dialog = builder.create();

        dialog.show();

        final View color_view = (View) ((AlertDialog) dialog).findViewById(R.id.color_view);
        // Seekbars
        final SeekBar red_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.red_slider);
        final SeekBar green_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.green_slider);
        final SeekBar blue_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.blue_slider);

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            replace_color = Color.argb(255, red_bar.getProgress(), green_bar.getProgress(), blue_bar.getProgress());
            draw_view.setSystemColor(replace_color);
            dialog.dismiss();
        });

        dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(v -> {
            // Set color
            replace_color= Color.argb(255, red_bar.getProgress(), green_bar.getProgress(), blue_bar.getProgress());
            color_view.setBackgroundColor(replace_color);
        });
    }


    private void saveDialog(final Page page) {
        final View layout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = layout.findViewById(R.id.name_edit);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Name");
        builder.setCancelable(true);
        builder.setView(layout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();

            if (name.isEmpty() || !resources.checkUnique(name))
            {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }
            // Save game
            saveImage(name);
            // Add to resources list
            resources.addUserImage(name);
            dialog.dismiss();
        });
    }

    public void saveImage(String name){
        Bitmap disp = draw_view.getBitmap();
        ImageView prev = findViewById(R.id.rand_image_view);
        prev.setImageBitmap(disp);
        String path_test = saveToInternalStorage(disp, name);
        resources.setPath(path_test);
    }

    private String saveToInternalStorage(Bitmap bitmapImage, String name){
        String name_full = name + ".jpg";
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,name_full);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }
}
