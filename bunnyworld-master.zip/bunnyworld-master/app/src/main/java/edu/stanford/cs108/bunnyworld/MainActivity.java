package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private BunnyWorldData data = BunnyWorldData.getInstance();
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = openOrCreateDatabase(BunnyWorldData.DB_NAME, MODE_PRIVATE, null);
        data.setDb(db);
        Cursor tablesCursor = db.rawQuery(
                "SELECT * FROM sqlite_master WHERE type='table' AND name='games';",
                null
        );
        if (tablesCursor.getCount() == 0) createAndSeedDatabase();

        tablesCursor.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.reset_database:
                resetDatabase();
                break;
            case R.id.import_game:
                importGame();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    private void importGame() {
        data.setEditMode(false);
        Intent intent = new Intent(this, FileSelectActivity.class);
        startActivity(intent);
    }


    public void onClickEditor(View view) {
        data.setEditMode(true);
        Intent intent = new Intent(this, GameListActivity.class);
        startActivity(intent);
    }

    public void onClickImageEditor(View view) {
        data.setEditMode(true);
        Intent intent = new Intent(this, ImageEditor.class);
        startActivity(intent);
    }

    public void onClickRandomEditor(View view){
        data.setEditMode(true);
        Intent intent = new Intent(this, RandomGenerator.class);
        startActivity(intent);
    }

    public void onClickPlay(View view) {
        data.setEditMode(false);
        Intent intent = new Intent(this, GameListActivity.class);
        startActivity(intent);
    }

    private void createAndSeedDatabase() {
        createGames();
        Demo.seed(this);
    }

    private void createGames() {
        String setupStr = "CREATE TABLE IF NOT EXISTS games ("
                + "name TEXT, game JSON,gameid INTEGER, "
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT"
                + ");";
        db.execSQL(setupStr);
    }

    private void resetDatabase() {
        db.execSQL("DROP TABLE IF EXISTS games;");
        createAndSeedDatabase();
        showResetNotification();
    }

    private void showResetNotification() {
        Toast toast = Toast.makeText(
                getApplicationContext(),
                getResources().getString(R.string.reset_toast),
                Toast.LENGTH_SHORT
        );

        toast.show();
    }
}
