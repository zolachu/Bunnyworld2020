package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.HashSet;
import java.util.List;

public class GameEditActivity extends AppCompatActivity {
    private ResourceList resourceList = ResourceList.getInstance();
    private BunnyWorldData data = BunnyWorldData.getInstance();
    private Game game;
    private ArrayAdapter pagesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        game = data.getSelectedGame();
        setTitle(getString(R.string.game_editor_title) + " - " + game.getName());
        setContentView(R.layout.activity_game_edit);

        ImageButton addPageBtn = findViewById(R.id.add_page);
        addPageBtn.setOnClickListener((view) -> pageDialog(null));

        ListView pageListView = findViewById(R.id.list_view);
        pageListView.setLongClickable(true);
        pageListView.setEmptyView(findViewById(R.id.empty));

        final List<Page> pages = game.getPages();
        pagesAdapter = new ArrayAdapter(
                this, android.R.layout.simple_list_item_2, android.R.id.text1, pages) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                Page page = pages.get(position);
                text1.setText(page.getName());
                text2.setText(
                    game.getStartPage().equals(page) ? getString(R.string.game_editor_start_page) : ""
                );

                return view;
            }
        };

        pagesAdapter.notifyDataSetChanged();
        pageListView.setAdapter(pagesAdapter);

        pageListView.setOnItemClickListener((parent, view, position, viewId) -> {
            data.setSelectedPage(pages.get(position));
            Intent intent = new Intent(this, PageEditActivity.class);
            startActivity(intent);
        });

        pageListView.setOnItemLongClickListener((parent, view, position, viewId) -> {
            pageDialog(pages.get(position));

            return true; // Prevent triggering the normal onClick listener
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.game_edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.rename_game:
                renameDialog();
                break;
            case R.id.export_game:
                if (gameContainsCustom()) {
                    AlertDialog understoodBuild = confirmMessage().create();
                    understoodBuild.show();
                } else {
                    AlertDialog alert = createYesNoButton().create();
                    alert.show();
                }
                break;
            case R.id.delete_game:
                deleteConfirmationDialog();
                break;
            case R.id.back:
                Intent intent = new Intent(this, GameListActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private boolean gameContainsCustom() {
        Game curr = data.getSelectedGame();
        HashSet<String> imgNames = new HashSet<>(resourceList.getResourceImgNames());
        List<Shape> allShapes = curr.getAllShapes();

        for (Shape currShape: allShapes) {
            if (!(imgNames.contains(currShape.getImageName()))){
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        pagesAdapter.notifyDataSetChanged();
    }

    private AlertDialog.Builder createYesNoButton() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(R.string.confirm_export);
        builder.setMessage(R.string.confirm_export_msg);

        builder.setPositiveButton(R.string.dialog_positive_btn, (dialog, which) -> {
            dialog.dismiss();

            try {
                String currPath = getFilesDir().toString();
                File tempFile = data.writeGameToFile(currPath,data.getSelectedGame());
                data.setExportFile(tempFile);
                Toast.makeText(getApplicationContext(), R.string.file_saved, Toast.LENGTH_LONG).show();

                Intent intent = new Intent(this, ExportFile.class);
                startActivity(intent);
            } catch(Exception e) {
                Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        builder.setNegativeButton(R.string.dialog_negative_btn, (dialog, which) -> dialog.dismiss());
        return builder;
    }

    private AlertDialog.Builder confirmMessage() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(R.string.confirm_export_understood);
        builder.setMessage(R.string.export_instructions);

        builder.setPositiveButton(R.string.dismiss_msg, (dialog, which) -> {
            dialog.dismiss();
            AlertDialog.Builder yesNo = createYesNoButton();
            AlertDialog alert = yesNo.create();
            alert.show();
        });
        return builder;
    }

    private void deleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.game_delete_title);
        builder.setMessage(R.string.game_delete_message);
        builder.setCancelable(true);
        builder.setPositiveButton(R.string.dialog_positive_btn, (dialog, which) -> {
                data.deleteGame(game.getId());
                this.finish();
        });
        builder.setNegativeButton(R.string.dialog_negative_btn, (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    private void renameDialog() {
        final View nameLayout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = nameLayout.findViewById(R.id.name_edit);
        editText.setText(game.getName());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.game_rename);
        builder.setCancelable(true);
        builder.setView(nameLayout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();
            if (name.isEmpty() || !data.isUniqueGameName(game.getId(), name)) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            game.setName(name);
            game = data.updateGame(game);
            setTitle(getString(R.string.game_editor_title) + " - " + game.getName());
            dialog.dismiss();
        });
    }

    /**
     * Renders an input dialog prompting for Page name and whether the page should be set as the
     * game start page.
     * @param page the page to be edited, may be null for a new page
     */
    private void pageDialog(final Page page) {
        final View layout = getLayoutInflater().inflate(R.layout.dialog_page_edit, null);
        final CheckBox startPage = layout.findViewById(R.id.start_page);
        final EditText editText = layout.findViewById(R.id.name_edit);

        if (page == null) {
            editText.setText(getString(R.string.page_default_name, game.getNumPages() + 1));
        } else {
            editText.setText(page.getName());
            startPage.setChecked(game.getStartPage().equals(page));
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(page == null ? R.string.page_new : R.string.page_edit);
        builder.setCancelable(true);
        builder.setView(layout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            boolean isStartPage = startPage.isChecked();
            String name = editText.getText().toString();

            if (name.isEmpty()
                    || (page == null && !game.isUniquePageName(name))
                    || (page != null && !page.getName().equalsIgnoreCase(name) && !game.isUniquePageName(name))
            ) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            Page p;
            if (page == null) {
                p = new Page(name);
                game.addPage(p);
            } else {
                page.setName(name);
                p = page;
            }

            if (isStartPage) game.setStartPage(p);

            game = data.updateGame(game);
            pagesAdapter.notifyDataSetChanged();
            dialog.dismiss();
        });
    }
}
