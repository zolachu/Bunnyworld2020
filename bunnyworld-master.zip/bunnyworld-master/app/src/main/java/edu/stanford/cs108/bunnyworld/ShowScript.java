package edu.stanford.cs108.bunnyworld;

import android.content.Context;

public class ShowScript extends ShapeScript {


    //parameter: a shape name that the ShowScript action is associated with
    public ShowScript(String shapeName, String conditionalName) {
        super(shapeName, conditionalName);
    }

    //parameters: list of all shapes in the game, the current view/activity.
    //directly changes the specified shape's state to not hidden
    @Override
    public void run(Game game, Context _context) {
        if (game == null) return;
        if (!inInventory()) return;

        Shape shape = game.getShapeByName(name);
        if (shape != null) shape.setHidden(false);
    }
}
