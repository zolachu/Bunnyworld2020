package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;

import androidx.annotation.Nullable;

import java.util.ArrayList;

import static android.graphics.Bitmap.Config.ARGB_8888;

// TODO -- BRUSH SIZE - 2, fill in neighbors!

public class PixelGrid extends View {

    // Actual dimensions of the view
    int viewWidth;
    int viewHeight;

    // Number of pixels in x and y directions
    int num_pixels;
    int total_pixels;
    // Size of a pixel
    float pixel_dim;

    int curr_color;

    CurrColors singleton;

    boolean size_changed = false;
    boolean redraw = false;

    Bitmap bitmap;

    ArrayList<Pixel> pixels = new ArrayList<>();
    ArrayList<Pixel> background = new ArrayList<>();

    private Canvas save_canvas;

    // Default constructor
    public PixelGrid(Context context, @Nullable AttributeSet attrs) {

        super(context, attrs);
    }

//    public void init(){
//        // Set up bitmap
//        bitmap = Bitmap.createBitmap(viewWidth, viewHeight, ARGB_8888);
//        save_canvas = new Canvas(bitmap);
//
//        findSize();
//        invalidate();
//    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh){
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
    }

    @Override
    public void onDraw(Canvas canvas){
        super.onDraw(canvas);
        // Draw the grid
        if (pixels.size() != 0) {
            for (Pixel pixel : pixels) {
                pixel.draw(canvas);
                //pixel.draw(save_canvas);
            }
        }
        // If redrawing because of size, change color back!
        if (size_changed){
            getColor();
            size_changed = false;
        }
        //save_canvas.save();
    }

    public Bitmap getBitmap(){
        Bitmap saved = Bitmap.createBitmap(this.viewWidth, this.viewHeight,ARGB_8888);
        Canvas canvas = new Canvas(saved);
        for (Pixel pixel : pixels){
            pixel.draw(canvas);
        }
        return saved;
    }

    // Color by tapping
    @Override
    public boolean onTouchEvent(MotionEvent event){
        if (event.getAction() ==  MotionEvent.ACTION_DOWN){
            for (Pixel pixel : pixels){
                if (pixel.insidePixel(event.getX(), event.getY())){
                    getColor();
                    pixel.setColor(curr_color);
                }
            }
            // Redraw
            invalidate();
        } else if (event.getAction() == MotionEvent.ACTION_MOVE){
            for (Pixel pixel : pixels){
                if (pixel.insidePixel(event.getX(), event.getY())){
                    getColor();
                    pixel.setColor(curr_color);
                }
            }
            // Redraw
            invalidate();
        }
        return true;
    }

    public void reset(){
        redraw = true;
        //invalidate();
        redraw = false;
    }

    public int returnHeight(){
        return viewHeight;
    }
    public int returnWidth(){
        return viewWidth;
    }

    // Call earlier!
    public void findSize(){
        // reset pixels
        pixels.clear();
        // Find new dimensions
        SeekBar size_slider = ((ImageEditor) getContext()).findViewById(R.id.size_slider);
        num_pixels = size_slider.getProgress(); // Dimensions
        total_pixels = num_pixels * num_pixels; // Total number on grid
        // Divide into even pixels
        pixel_dim = viewHeight / num_pixels;
        size_changed = true;
        int init_color = Color.WHITE;
//        int back_color;
        // Create the pixels
        for (int i = 0; i < num_pixels; i++){
            for (int j = 0; j < num_pixels; j++){
                Pixel new_pixel = new Pixel((0 + (pixel_dim * i)), (0 + (pixel_dim * j)), pixel_dim, init_color);
                pixels.add(new_pixel);
//                if (j % 2 == 0){
//                    if (i % 2 == 0){
//                        back_color = Color.WHITE;
//                    } else {
//                        back_color = Color.GRAY;
//                    }
//                } else{
//                    if (i % 2 == 0){
//                        back_color = Color.GRAY;
//                    } else {
//                        back_color = Color.WHITE;
//                    }
//                }
//                new_pixel.setColor(back_color);
//                background.add(new_pixel);

            }
        }
    }

    public void getColor(){
        singleton = CurrColors.getInstance();
        curr_color = singleton.getCurrColor();
    }

}
