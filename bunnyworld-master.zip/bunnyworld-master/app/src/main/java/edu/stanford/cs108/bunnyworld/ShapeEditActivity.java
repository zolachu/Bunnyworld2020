package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.w3c.dom.Text;

public class ShapeEditActivity extends AppCompatActivity {
    private BunnyWorldData data;
    private Game game;
    private Shape shape; // THIS NEEDS TO BE PASSED IN
    private Page page; // Page this is associated with
    private ArrayAdapter shapesAdapter;
    // HARDCODED FOR NOW
    BitmapDrawable placeholder;
    String[] image_list;
    ResourceList resources = ResourceList.getInstance();

    private float oldY;
    private float oldX;
    private float oldHeight;
    private float oldWidth;
    private boolean oldSelectable;
    private boolean oldMovable;
    private boolean oldHidden;
    private String oldName;
    private String oldScript;
    private transient BitmapDrawable oldImage;
    private String oldImageName;
    private String oldText;
    private int oldTextSize;

    private boolean oldFontAntialias;
    private int oldFontHinting;
    private String oldFontFeatureSetting;
    private boolean oldFontFakeBold;
    private float oldFontScale;
    private float oldFontSkew;
    private float oldLetterSpacing;
    private Paint.Style oldCustomStyle;
    private Typeface oldTypeFace;
    private boolean oldFontStrikeThrough;
    private boolean oldFontUnderline;
    private int oldColor;
    private boolean oldIsText;

    // Dropdown menu to choose images plus adapter
    Spinner dropdown;
    ArrayAdapter<String> img_adapter;

    Button script_button;

    ShapePreviewDraw preview_window;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        data = BunnyWorldData.getInstance();
        // SET SHAPE TO THE ONE BEING EDITED
        game = data.getSelectedGame();
        shape = data.getSelectedShape();
        page = data.getSelectedPage();
        setTitle(getString(R.string.shape_editor_title) + " - " + shape.getName());
        setContentView(R.layout.activity_shape_edit);

        // Update list of images
        image_list = resources.getImages();

        // TODO - reset the image to the correct one here?

        // Only make image dropdown visible if type is checked
        final TextView image_select = (TextView) findViewById(R.id.choose_img_txt);

        Button text_edit_button = findViewById(R.id.text_edit_button);

        // Setting up 'choose image' dropdown
        dropdown = findViewById(R.id.image_dropdown);
        // Create adapter from the images list
        img_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, image_list);
        img_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //set the spinners adapter to the previously created one.
        dropdown.setAdapter(img_adapter);

        Button save_changes = findViewById(R.id.save_button);
//        script_button = findViewById(R.id.script_button);
//        script_button.setOnClickListener((view) -> scriptDialog());

        Button default_rect = findViewById(R.id.default_rect);
        default_rect.setSelected(true);

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.type_group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                  @Override
                                                  public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                      if(checkedId == R.id.image){
                                                          image_select.setVisibility(View.VISIBLE);
                                                          dropdown.setVisibility(View.VISIBLE);
                                                          text_edit_button.setVisibility(View.INVISIBLE);
//
                                                      } else if (checkedId == R.id.text){
                                                          image_select.setVisibility(View.INVISIBLE);
                                                          dropdown.setVisibility(View.INVISIBLE);
                                                          text_edit_button.setVisibility(View.VISIBLE);

                                                      } else {
                                                          image_select.setVisibility(View.INVISIBLE);
                                                          dropdown.setVisibility(View.INVISIBLE);
                                                          text_edit_button.setVisibility(View.INVISIBLE);
//
                                                      }
                                                  }
                                              }
        );
        displayCurrentVals();
        // Set up the Preview image
        preview_window = findViewById(R.id.shape_preview);
        preview_window.setShape(shape);
        preview_window.redraw();

    } // END onCreate
    // IMAGE SELECTION
//    Spinner
//            SpinnerAdapter
//    AdapterView.OnItemSelectedListener

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.shape_edit_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit:
                editDialog();
                break;
            case R.id.delete:
                deleteConfirmationDialog();
                break;
            case R.id.back:
                Intent intent = new Intent(this, PageEditActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    public void displayCurrentVals(){

        TextView shape_name = findViewById(R.id.name_prev);
        TextView x_prev = findViewById(R.id.x_prev);
        TextView y_prev = findViewById(R.id.y_prev);
        TextView width_prev = findViewById(R.id.width_prev);
        TextView height_prev = findViewById(R.id.height_prev);

        TextView text_prev = findViewById(R.id.text_prev);
        TextView image_name = findViewById(R.id.image_prev);

        CheckBox selectable_prev = findViewById(R.id.selectable_prev);
        CheckBox movable_prev = findViewById(R.id.movable_prev);
        CheckBox hidden_prev = findViewById(R.id.hidden_prev);


        TextView script_preview = findViewById(R.id.script_prev);
        script_preview.setText(shape.getScripts());
        shape_name.setText(shape.getName());
        // Set values
        x_prev.setText(String.valueOf(shape.getX()));
        y_prev.setText(String.valueOf(shape.getY()));
        width_prev.setText(String.valueOf(shape.getWidth()));
        height_prev.setText(String.valueOf(shape.getHeight()));

        text_prev.setText(shape.getText());
        image_name.setText(shape.getImageName());

        if (shape.getHidden()){
            hidden_prev.setChecked(true);
        }
        if (shape.getSelectable()){
            selectable_prev.setChecked(true);
        }
        movable_prev.setChecked(shape.isMovable());
    }

    // (String trigger, String action, String name
    public boolean addScript(View view){
        // TODO - add error checking HERE
        EditText script_text = findViewById(R.id.script_edit);
        // Error checking
        shape.addScript(script_text.getText().toString());
        return true;
    }

    public void removeScripts(View view){
        shape.removeScripts();
    }
    //restores shape to last save state with 1-deep undo capability
    public void undoLastChange(View view) {
        shape.undo();
        data.updateGame(game);

        // Return to the page activity
        Intent intent = new Intent(this, PageEditActivity.class);
        startActivity(intent);
    }

    public void copy(View view) {
        page.copyShape(shape);
        data.updateGame(game);

        // Return to the page activity
        Intent intent = new Intent(this, PageEditActivity.class);
        startActivity(intent);
    }

    public void cut(View view) {
        page.cut(shape);
        data.updateGame(game);

        // Return to the page activity
        Intent intent = new Intent(this, PageEditActivity.class);
        startActivity(intent);
    }

        public void makeChanges(View view){

        //save shape's backup state for future undo
        oldScript = shape.getScriptText();
        oldName = shape.getName();
        oldX = shape.getX();
        oldY = shape.getY();
        oldWidth = shape.getWidth();
        oldHeight = shape.getHeight();
        oldText = shape.getText();
        oldTextSize = shape.getTextSize();
        oldImageName = shape.getImageName();

        oldFontAntialias = shape.fontAntialias;
        oldFontHinting = shape.fontHinting;
        oldFontFeatureSetting = shape.fontFeatureSetting;
        oldFontFakeBold = shape.fontFakeBold;
        oldFontScale = shape.fontScale;
        oldFontSkew = shape.fontSkew;
        oldLetterSpacing = shape.letterSpacing;
        oldCustomStyle = shape.customStyle;
        oldTypeFace = shape.typeFace;
        oldFontStrikeThrough = shape.fontStrikeThrough;
        oldFontUnderline = shape.fontUnderline;
        oldColor = shape.color;
        oldIsText = shape.getTextFlag();
        if(!oldImageName.isEmpty()) {
            if (!resources.checkLocal(oldImageName)){
                try {
                    // get drawable resource ID for given name
                    int image_id = getResources().getIdentifier(
                            oldImageName,
                            "drawable",
                            getPackageName()
                    );

                    // get the actual bitmap resource
                    oldImage = (BitmapDrawable) getResources().getDrawable(
                            image_id, getApplicationContext().getTheme()
                    );
                } catch (NullPointerException | Resources.NotFoundException exception) {
                    return;
                }
            } else {
                oldImage = loadImageFromStorage(resources.getPath(), oldImageName);
            }

        }
        oldMovable = shape.isMovable();
        oldSelectable = shape.getSelectable();
        oldHidden = shape.getHidden();
        shape.saveBackup(oldX, oldY, oldHeight, oldWidth, oldSelectable, oldMovable, oldHidden,
                oldName, oldScript, oldImage, oldImageName, oldText, oldTextSize, oldFontAntialias,
                oldFontHinting, oldFontFeatureSetting, oldFontFakeBold, oldFontScale, oldFontSkew,
                oldLetterSpacing, oldCustomStyle, oldTypeFace, oldFontStrikeThrough,
                oldFontUnderline, oldColor, oldIsText);

        // Set coordinates...
        EditText x_val = findViewById(R.id.x_edit);
        EditText y_val = findViewById(R.id.y_edit);
        EditText height_val = findViewById(R.id.height_edit);
        EditText width_val = findViewById(R.id.width_edit);

        // Set coordinates
        if(!isEmpty(x_val)){
            Log.d("vals", x_val.toString());
            // shape.setX(10.0f);
            shape.setX(Float.valueOf(x_val.getText().toString()));
        }
        if(!isEmpty(y_val)){
            Log.d("vals", y_val.toString());
            // shape.setY(10.0f);
            shape.setY(Float.valueOf(y_val.getText().toString()));
        }
        if(!isEmpty(height_val)){
            Log.d("vals", height_val.toString());
            Log.d("x_val", x_val.toString());
            shape.setHeight(Float.valueOf(height_val.getText().toString()));
        }
        if(!isEmpty(width_val)){
            Log.d("vals", width_val.toString());
            Log.d("x_val", x_val.toString());

            shape.setWidth(Float.valueOf(width_val.getText().toString()));
        }

        // Based on selected shape type, add text/image as appropriate
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.type_group);
        int checked = radioGroup.getCheckedRadioButtonId();
        switch (checked){
            case R.id.image: // Set image
                if (dropdown.getSelectedItem() != null){
                    shape.setText(""); // clear out the text
                    addImage();
                    break;
                } else {
                    // error
                    break;
                }
            case R.id.text: // set text
                Button text = findViewById(R.id.text);
                text.setSelected(true);
                EditText text_val = findViewById(R.id.text_edit);
                EditText font_size = findViewById(R.id.font_size_edit);
                if (!isEmpty(font_size)){
                    shape.setTextSize(Integer.valueOf(font_size.getText().toString()));
                }
                if (!isEmpty(text_val)){
                    shape.setText(text_val.getText().toString());
                    shape.removeImage();
                } else {
                    // throw error
                    break;
                }
                break;
            case R.id.default_rect:
                shape.resetToDefault();
            default:
                break;
        }

        // Set selectable/movable/hidden
        CheckBox selectable = findViewById(R.id.selectable_check);
        if (selectable.isChecked()){
            shape.setSelectable(true);
        }
        CheckBox movable = findViewById(R.id.movable_check);
        if (movable.isChecked()){
            shape.setMovable(true);
        }
        CheckBox hidden = findViewById(R.id.hidden_check);
        if (hidden.isChecked()){
            shape.setHidden(true);
        }

        // Additional call to updateGame
        Game game = data.getSelectedGame();
        data.updateGame(game);

        // Return to the page activity
        Intent intent = new Intent(this, PageEditActivity.class);
        startActivity(intent);
    }

    public void addImage(){
        String image_name = dropdown.getSelectedItem().toString(); // Should already be a string!
        BitmapDrawable image_drawable;
        if (!resources.checkLocal(image_name)){
            // get the ID from the name
            int image_id =  ShapeEditActivity.this.getResources().getIdentifier(
                    image_name,
                    "drawable",
                    getPackageName()
            );
            // get the actual bitmap
            image_drawable = (BitmapDrawable) getResources().getDrawable(image_id, getApplicationContext().getTheme());
        } else {
            image_drawable = loadImageFromStorage(resources.getPath(), image_name);
        }
        shape.setDrawable(image_name, image_drawable);
    }
    // Same as in shape, based on https://stackoverflow.com/questions/17674634/saving-and-reading-bitmaps-images-from-internal-memory-in-android
    // Based on top two/three answers
    private BitmapDrawable loadImageFromStorage(String path, String name) {
        BitmapDrawable d = null;
        String name_full = name + ".jpg";
        try {
            File f=new File(path, name_full);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            d = new BitmapDrawable(getResources(), b);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        return d;
    }

    // True if empty, false if not
    private boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }


    public void editText(View view) {
        Intent intent = new Intent(this, DrawMainActivity.class);
        startActivity(intent);
    }

    private void deleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.shape_delete_title);
        builder.setMessage(R.string.shape_delete_message);
        builder.setCancelable(true);
        builder.setPositiveButton(R.string.dialog_positive_btn, (dialog, which) -> {
            page.removeShape(shape);
            data.setSelectedShape(null);
            data.updateGame(game);
            this.finish();
        });
        builder.setNegativeButton(R.string.dialog_negative_btn, (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    private void editDialog() {
        final View layout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = layout.findViewById(R.id.name_edit);

        editText.setText(shape.getName());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.shape_editor_title);
        builder.setCancelable(true);
        builder.setView(layout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();
            if (name.isEmpty() ||
                    (!shape.getName().equalsIgnoreCase(name) && !game.isUniqueShapeName(name))
            ) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            oldName = shape.getName();
            shape.setName(name);
            data.updateGame(game);
            setTitle(getString(R.string.shape_editor_title) + " - " + shape.getName());
            dialog.dismiss();
            //save shape's backup state for future undo
            oldScript = shape.getScriptText();
            oldX = shape.getX();
            oldY = shape.getY();
            oldWidth = shape.getWidth();
            oldHeight = shape.getHeight();
            oldText = shape.getText();
            oldTextSize = shape.getTextSize();
            oldImageName = shape.getImageName();
            oldFontAntialias = shape.fontAntialias;
            oldFontHinting = shape.fontHinting;
            oldFontFeatureSetting = shape.fontFeatureSetting;
            oldFontFakeBold = shape.fontFakeBold;
            oldFontScale = shape.fontScale;
            oldFontSkew = shape.fontSkew;
            oldLetterSpacing = shape.letterSpacing;
            oldCustomStyle = shape.customStyle;
            oldTypeFace = shape.typeFace;
            oldFontStrikeThrough = shape.fontStrikeThrough;
            oldFontUnderline = shape.fontUnderline;
            oldColor = shape.color;
            oldIsText = shape.getTextFlag();
            if(!oldImageName.isEmpty()) {
                if (!resources.checkLocal(oldImageName)){
                    try {
                        // get drawable resource ID for given name
                        int image_id = getResources().getIdentifier(
                                oldImageName,
                                "drawable",
                                getPackageName()
                        );

                        // get the actual bitmap resource
                        oldImage = (BitmapDrawable) getResources().getDrawable(
                                image_id, getApplicationContext().getTheme()
                        );
                    } catch (NullPointerException | Resources.NotFoundException exception) {
                        return;
                    }
                } else {
                    oldImage = loadImageFromStorage(resources.getPath(), oldImageName);
                }

            }
            oldMovable = shape.isMovable();
            oldSelectable = shape.getSelectable();
            oldHidden = shape.getHidden();
            shape.saveBackup(oldX, oldY, oldHeight, oldWidth, oldSelectable, oldMovable, oldHidden,
                oldName, oldScript, oldImage, oldImageName, oldText, oldTextSize, oldFontAntialias,
                oldFontHinting, oldFontFeatureSetting, oldFontFakeBold, oldFontScale, oldFontSkew,
                oldLetterSpacing, oldCustomStyle, oldTypeFace, oldFontStrikeThrough,
                oldFontUnderline, oldColor, oldIsText);
            Intent intent = new Intent(this, PageEditActivity.class);
            startActivity(intent);
        });
    }
}
