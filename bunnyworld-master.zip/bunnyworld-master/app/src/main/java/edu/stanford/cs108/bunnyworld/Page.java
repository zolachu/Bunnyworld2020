package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;


public class Page {
    static final String DEFAULT_NAME = "page1";
    private String name;
    private int backgroundColor;
    private Paint backgroundFill;
    private List<Shape> shapes;

    public Page() {
        this(DEFAULT_NAME);
    }

    public Page(String name){
        this.name = name;
        this.shapes = new ArrayList<Shape>();

        backgroundColor = Color.WHITE;
        initPaint();
    }

    public int getColor() {
        return backgroundColor;
    }

    public void setBackgroundFill(int color) {
        backgroundFill = new Paint();
        backgroundFill.setColor(color);
        backgroundColor = color;
        backgroundFill.setStyle(Paint.Style.FILL);
    }
    private void initPaint() {
        backgroundFill = new Paint();
        backgroundFill.setColor(backgroundColor);
        backgroundFill.setStyle(Paint.Style.FILL);
    }

    /*
     * Draw all visible shapes in the shapes list. The main draw method used in game play.
     * Note: Hidden shapes are not drawn with this method!
     */
    public void draw(Canvas canvas, Context context) {
        drawPage(canvas, context, false);
    }

    /*
     * Draw all shapes in the shapes list, including hidden shapes. Used in page editor.
     */
    public void drawAllShapes(Canvas canvas, Context context) {
        drawPage(canvas, context, true);
    }

    /*
     * Draw shapes in the shapes list.
     * If given boolean is true, hidden shapes are also drawn.
     */
    private void drawPage(Canvas canvas, Context context, boolean drawHidden) {
        canvas.drawPaint(backgroundFill);
        for (Shape shape : shapes) {
            if (shape.getHidden() && !drawHidden) continue;

            shape.draw(canvas, context);
        }
    }

    /*
     * Returns the list of shapes.
     */
    public List<Shape> getShapes() {
        return this.shapes;
    }

    /*
     * Returns the page name.
     */
    public String getName() {
        return this.name;
    }

    /*
     * Returns the shape at the given coordinates if one exists, otherwise null.
     * Iterates shapes in reverse to get the top most (most recently added) shape.
     */
    public Shape getShapeAt(float x, float y) {
        if (shapes == null || shapes.isEmpty()) return null;

        for (int i = shapes.size() - 1; i >= 0; i--) {
            Shape shape = shapes.get(i);
            if (shape.insideShape(x, y)) return shape;
        }

        return null;
    }

    /*
     * Returns a selectable shape at the given coordinates if one exists, otherwise null.
     */
    public Shape getSelectableShapeAt(float x, float y) {
        Shape shape = getShapeAt(x, y);
        if (shape != null && shape.getSelectable()) return shape;

        return null;
    }

    /*
     * Returns a shape at the given coordinates if one exists, otherwise null.
     * Ignores shapes with the given ignoreName. This is useful when determining if a shape was
     * dropped on another shape.
     * @param x horizontal location
     * @param y vertical location
     * @param ignoreName name of shape to ignore
     * @return shape at given coordinates if one exists, else null
     */
    public Shape getUniqueShapeAt(float x, float y, String ignoreName) {
        Shape shape = getShapeAt(x, y);
        if (shape == null || shape.getName().equalsIgnoreCase(ignoreName)) return null;

        return shape;
    }

    /*
     * Calls all onEnter actions for page shapes with given game, and activity context.
     */
    public void onEnter(Game game, Context context) {
        for (Shape shape : shapes) {
            shape.onEnter(game, context);
        }
    }

    /*
     * Sets the page name.
     */
    public void setName(String name) {
        this.name = name;

    }

    /*
     * Sets hovered state for all selectable page shapes.
     * A page shape is drawn with highlight border when hovered is true.
     */
    public void setShapesHovered(boolean choice) {
        for (Shape shape : shapes) {
            if (shape.getSelectable()) shape.setHovered(choice);
        }
    }

    /*
     * Deletes the current page and deletes the shapes on this page.
     */
     public void deletePage() {
          
          
     }

    /*
     * Adds a shape to the shapes list.
     */
    public void addShape(Shape shape) {
        if (!shapes.contains(shape)) {
            this.shapes.add(shape);
        }
    }

    /*
     * Removes a shape from the shapes list.
     */
    public void removeShape(Shape shape) {
        if (shapes.contains(shape)) {
            this.shapes.remove(shape);
        }
    }

    /*
     * Removes all shapes from the shapes list.
     */
    public void clearShapes(){
        this.shapes.clear();
    }

    public boolean equals(Page page) {
        return this.name.toLowerCase().equals(page.getName().toLowerCase());
    }

    @Override
    public String toString() {
        // Return the name of the Page
        return this.name;
    }

    public int getNumShapes() {
        return shapes.size();
    }

    /**
     * Highlight page shapes with corresponding onDrop action for given shape
     * @param selectedShape
     */
    public void highlightShapesWithOnDrop(Shape selectedShape) {
        if (selectedShape == null) return;

        for (Shape shape : shapes) {
            if (shape.inOnDrop(selectedShape.getName()) && shape.getSelectable()) {
                shape.setHovered(true);
            }
        }
    }

    public static Page JSONtoPage(String JSONstring) {
        Gson gsonBuilder = new GsonBuilder().create();

        Page currentPage = gsonBuilder.fromJson(JSONstring, Page.class);
        currentPage.initPaint();
        currentPage.shapes = new ArrayList<Shape>();

        JsonElement jsonTree = JsonParser.parseString(JSONstring);

        if (jsonTree.isJsonObject()) {
            JsonObject jsonObject = jsonTree.getAsJsonObject();
            JsonElement shapeElem = jsonObject.get("shapes");

            if (shapeElem.isJsonArray()) {
                JsonArray shapeArray = shapeElem.getAsJsonArray();
                for (int i = 0; i < shapeArray.size(); i++) {
                    if (shapeArray.get(i).isJsonObject()) {
                        JsonObject newShape = shapeArray.get(i).getAsJsonObject();
                        Shape shape = Shape.JSONtoShape(newShape.toString());

                        currentPage.addShape(shape);
                    }
                }
            }
        } else {
            throw new InvalidParameterException("The format of the string isn't in a valid JSON format");
        }

        return currentPage;
    }

    public void cut(Shape shape) {
        copyShape(shape);
        removeShape(shape);
    }

    public void paste() {
        BunnyWorldData data = BunnyWorldData.getInstance();
        if(data.getCopiedShape() != null) {
            while (containsShapeName(data.getCopiedShape().getName())) {
                copyShape(data.getCopiedShape());
            }
            addShape(data.getCopiedShape());
        }
    }

    public boolean containsShapeName(String shapeName) {
        BunnyWorldData data = BunnyWorldData.getInstance();
        boolean contains = false;
        for(Shape shape : data.getSelectedGame().getAllShapes()) {
            if(shape.getName().equalsIgnoreCase(shapeName)) {
                contains = true;
            }
        }
        return contains;
    }

    public void copyShape(Shape shape) {
        BunnyWorldData data = BunnyWorldData.getInstance();
        String copyName = pickShapeCopyName(shape);
        Shape newCopiedShape = new Shape(copyName, shape);
        data.setCopiedShape(newCopiedShape);
    }

    public String pickShapeCopyName(Shape shape) {
        String shapeName = shape.getName();
        shapeName += "Copy";
        return shapeName;
    }
}
