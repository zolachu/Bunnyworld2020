package edu.stanford.cs108.bunnyworld;

import android.content.Context;

public class ShrinkScript extends ShapeScript {
    //parameter: a shape name that the ShowScript action is associated with
    public ShrinkScript(String shapeName, String conditionalName) {
        super(shapeName, conditionalName);
    }

    //parameters: list of all shapes in the game, the current view/activity.
    //directly decreases the specified shape's size
    @Override
    public void run(Game game, Context _context) {
        if (game == null) return;
        if (!inInventory()) return;

        Shape shape = game.getShapeByName(name);
        if (shape != null) shape.shrink();
    }
}
