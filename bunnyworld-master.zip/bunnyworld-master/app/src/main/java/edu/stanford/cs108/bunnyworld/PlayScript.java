package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.media.MediaPlayer;

import java.util.List;


public class PlayScript extends ShapeScript {

    //parameter: name of a sound
    public PlayScript(String soundName, String conditionalName) {
        super(soundName, conditionalName);
    }

    //parameters: the current game, the current view/activity
    //creates the appropriate MediaPlayer and plays the corresponding
    // mp3 file according to the name String
    @Override
    public void run(Game _game, Context c) {
        if (!inInventory()) return;
        
        if (name.equals("carrotcarrotcarrot")) {
            playCarrot(c);
        } else if (name.equals("evillaugh")) {
            playEvil(c);
        } else if (name.equals("hooray")) {
            playHooray(c);
        } else if (name.equals("munch")) {
            playMunch(c);
        } else if (name.equals("munching")) {
            playMunching(c);
        } else if (name.equals("woof")) {
            playWoof(c);
        } else if (name.equals("fire")) {
            playFire(c);
        }
    }

    private void playCarrot(Context c) {
        MediaPlayer mp = MediaPlayer.create(c, R.raw.carrotcarrotcarrot);
        mp.start();
    }

    private void playEvil(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.evillaugh);
        mp.start();
    }

    private void playFire(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.fire);
        mp.start();
    }

    private void playHooray(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.hooray);
        mp.start();
    }

    private void playMunch(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.munch);
        mp.start();
    }

    private void playMunching(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.munching);
        mp.start();
    }

    private void playWoof(Context c) {

        MediaPlayer mp = MediaPlayer.create(c, R.raw.woof);
        mp.start();
    }
}
