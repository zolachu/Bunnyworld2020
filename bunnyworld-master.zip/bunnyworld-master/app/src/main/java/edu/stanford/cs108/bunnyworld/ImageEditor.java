package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.graphics.Bitmap.Config.ARGB_8888;

// TODO - BRUSH SIZE - FILL IN NEIGHBORS IN PIXELGRID

public class ImageEditor extends AppCompatActivity {
    final Context context = this;

//    Spinner dropdown;

    PixelGrid pixelGrid;

    CurrColors curr_color;

    ResourceList resources = ResourceList.getInstance();;

    String path_test;

    boolean replace = false;
    int replace_color;

    // get primary colors from another thing?
    // Set up initial colors!
    Button color1;
    Button color2;
    Button color3;
    Button color4;
    Button color5;
    Button color6;
    Button color7;
    Button color8;
    Button color9;
    Button color10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_editor);

        pixelGrid = findViewById(R.id.pixel_grid);

        //curr_color = new CurrColors();
        curr_color = CurrColors.getInstance();
        curr_color.setCurrColor(Color.WHITE);
        curr_color.getCurrColor();

        Button save_button = findViewById(R.id.save_button);
        save_button.setOnClickListener((view) -> saveDialog(null));

        // Set colors
        setInitColors();
    }
    private void setInitColors(){
        // Set up initial colors!
        color1 = findViewById(R.id.color1);
        color2 = findViewById(R.id.color2);
        color3 = findViewById(R.id.color3);
        color4 = findViewById(R.id.color4);
        color5 = findViewById(R.id.color5);
        color6 = findViewById(R.id.color6);
        color7 = findViewById(R.id.color7);
        color8 = findViewById(R.id.color8);
        color9 = findViewById(R.id.color9);
        color10 = findViewById(R.id.color10);

        color1.setBackgroundColor(Color.parseColor("#FF0000")); // red
        color2.setBackgroundColor(Color.parseColor("#F7B32B")); // yellow
        color3.setBackgroundColor(Color.parseColor("#212D40"));; // blue
        color4.setBackgroundColor(Color.parseColor("#000000"));; // black
        color5.setBackgroundColor(Color.parseColor("#808080"));; // ??
        color6.setBackgroundColor(Color.parseColor("#FF7F11"));; // oj
        color7.setBackgroundColor(Color.parseColor("#44633F"));; // green
        color8.setBackgroundColor(Color.parseColor("#2D1E2F"));; // purple
        color9.setBackgroundColor(Color.parseColor("#FFFFFF"));; // white
        color10.setBackgroundColor(Color.parseColor("#C0C0C0"));; // ??
        // not working!
        //pixelGrid.init();
    }

    // Maybe in colorpickerdialogue?
    public void replaceColor(View view){
        final View layout = getLayoutInflater().inflate(R.layout.dialog_color_picker, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose New Color");
        builder.setCancelable(true);
        builder.setView(layout);

        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton("Choose", (dialog, which) -> {});
        builder.setNeutralButton("Try Color", (dialog, which) -> {});
        final AlertDialog dialog = builder.create();

        dialog.show();

        final View color_view = (View) ((AlertDialog) dialog).findViewById(R.id.color_view);
        // Seekbars
        final SeekBar red_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.red_slider);
        final SeekBar green_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.green_slider);
        final SeekBar blue_bar = (SeekBar) ((AlertDialog) dialog).findViewById(R.id.blue_slider);

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            replace_color = Color.argb(255, red_bar.getProgress(), green_bar.getProgress(), blue_bar.getProgress());
            replace = true;
            dialog.dismiss();
        });

        dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(v -> {
            // Set color
            replace_color= Color.argb(255, red_bar.getProgress(), green_bar.getProgress(), blue_bar.getProgress());
            color_view.setBackgroundColor(replace_color);
        });
    }


    private void saveDialog(final Page page) {
        final View layout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = layout.findViewById(R.id.name_edit);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Name");
        builder.setCancelable(true);
        builder.setView(layout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();

            if (name.isEmpty() || !resources.checkUnique(name))
            {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            // Save game
            saveImage(name);
            // Add to resources
            resources.addUserImage(name);
            dialog.dismiss();
        });
    }
//
    public void saveImage(String name){
        Bitmap disp = pixelGrid.getBitmap();
        ImageView prev = findViewById(R.id.image_view);
        prev.setImageBitmap(disp);
        path_test = saveToInternalStorage(disp, name);
        resources.setPath(path_test);
        System.out.println(path_test);
    }

    public void loadImage(View view){
        loadImageFromStorage(path_test, "test");
    }

    // Based on https://stackoverflow.com/questions/17674634/saving-and-reading-bitmaps-images-from-internal-memory-in-android
    private String saveToInternalStorage(Bitmap bitmapImage, String name){
        String name_full = name + ".jpg";
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory,name_full);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }
    // Same as in shape, based on https://stackoverflow.com/questions/17674634/saving-and-reading-bitmaps-images-from-internal-memory-in-android
    // Based on top two/three answers
    private void loadImageFromStorage(String path, String name) {
        String name_full = name + ".jpg";
        try {
            File f=new File(path, name_full);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            ImageView img=(ImageView)findViewById(R.id.image_view);
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

    }

    public void changeColor(View view){

    }


    public void setColor(View view){
        Button selected = findViewById(view.getId());

        // If we have a new color chosen, replace the button's current  color
        if (replace){
            selected.setBackgroundColor(replace_color);
            replace = false;
        }

        // Change the draw color to the button's

        int color = 0;
        Drawable background = selected.getBackground();
        if (background instanceof ColorDrawable) {
            color = ((ColorDrawable)background).getColor();
        }
        curr_color.setCurrColor(color);

    }

    public void setSize(View view){
        pixelGrid.reset();
        // Redraw the grid!
        pixelGrid.findSize();
        // Redraw
        pixelGrid.invalidate();
    }

}
