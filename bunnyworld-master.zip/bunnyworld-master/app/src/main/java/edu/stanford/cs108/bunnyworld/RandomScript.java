package edu.stanford.cs108.bunnyworld;

import android.content.Context;

public class RandomScript extends ShapeScript {
    //parameter: a shape name that the ShowScript action is associated with
    public RandomScript(String shapeName, String conditionalName) {
        super(shapeName, conditionalName);
    }

    //parameters: list of all shapes in the game, the current view/activity.
    //directly changes the specified shape's location to a random one on the page
    @Override
    public void run(Game game, Context _context) {
        if (game == null) return;
        if (!inInventory()) return;

        Shape shape = game.getShapeByName(name);
        if (shape != null) shape.random();
    }
}
