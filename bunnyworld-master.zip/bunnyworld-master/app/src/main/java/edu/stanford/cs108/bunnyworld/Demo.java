package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Demo {
    private static final int DEFAULT_DOOR_X = 600;
    private static final int DEFAULT_DOOR_Y = 750;
    private static final int DEFAULT_PROMPT_TEXT_SIZE = 100;
    private static final int DEFAULT_PROMPT_X = 200;
    private static final int DEFAULT_PROMPT_Y = 700;
    private static final int DEFAULT_SHAPE_PADDING = 200;
    private static final int DEFAULT_SUBJECT_HEIGHT = 400;
    private static final int DEFAULT_SUBJECT_WIDTH = 400;
    private static final int DEFAULT_SUBJECT_X = 600;
    private static final int DEFAULT_SUBJECT_Y = 200;
    private static final String NAME = "Demo";
    private static final int N_VICTORY_CARROTS = 6;
    private static final String SCENE_DEATH_BUNNY = "deathBunnyScene";
    private static final String SCENE_FIRE = "fireScene";
    private static final String SCENE_MYSTIC_BUNNY = "mysticBunnyScene";
    private static final String SCENE_VICTORY = "victoryScene";

    private final Context context;
    private SQLiteDatabase db;
    private BunnyWorldData data;

    private Demo(Context context) {
        this.data = BunnyWorldData.getInstance();
        this.db = data.getDb();
        this.context = context;
    }

    public static void seed(Context context) {
        if (context == null) return;

        Demo demo = new Demo(context);
        if (demo.hasInvalidDB()) return;

        demo.seed();
    }

    // TODO: Remove this hack. It was only implemented to get around gson issue with database
    public static Game getGame(Context context) {
        if (context == null) return null;

        Demo demo = new Demo(context);
        Game game = new Game(100000, NAME);
        demo.buildGame(game);
        return game;
    }

    private boolean hasInvalidDB() {
        return db == null;
    }

    private Game buildGame(Game game) {
        buildStartPage(game);
        game.addPage(buildDeathPage());
        game.addPage(buildFirePage());
        game.addPage(buildMysticPage());
        game.addPage(buildVictoryPage());
        return game;
    }

    private void seed() {
        Game game = data.createGame(NAME);
        game = buildGame(game);
        data.updateGame(game);
    }

    private Page buildDeathPage() {
        Page page = new Page(SCENE_DEATH_BUNNY);

        Shape death = new Shape("deathBunny");
        death.setSelectable(true);
        death.setX(DEFAULT_SUBJECT_X);
        death.setY(DEFAULT_SUBJECT_Y);
        death.setWidth(DEFAULT_SUBJECT_WIDTH);
        death.setHeight(DEFAULT_SUBJECT_HEIGHT);
        death.setImage("death", context);
        death.addScript("on enter play evillaugh");
        death.addScript("on click play evillaugh");
        death.addScript("on drop carrot hide carrot play munching hide deathBunny show deathExit");
        page.addShape(death);

        Shape actionPrompt = new Shape("deathPrompt");
        actionPrompt.setTextFlag(true);
        actionPrompt.setTextSize(DEFAULT_PROMPT_TEXT_SIZE);
        actionPrompt.setText("You must appease the Bunny of Death!");
        actionPrompt.setX(DEFAULT_PROMPT_X);
        actionPrompt.setY(DEFAULT_PROMPT_Y);
        page.addShape(actionPrompt);

        Shape exit = new Shape("deathExit");
        exit.setSelectable(true);
        exit.setHidden(true);
        exit.setX(DEFAULT_DOOR_X);
        exit.setY(DEFAULT_DOOR_Y);
        exit.addScript("on click goto " + SCENE_VICTORY);
        page.addShape(exit);

        return page;
    }

    private Page buildFirePage() {
        Page page = new Page(SCENE_FIRE);

        Shape fire = new Shape("fire");
        fire.setX(DEFAULT_SUBJECT_X);
        fire.setY(DEFAULT_SUBJECT_Y);
        fire.setWidth(DEFAULT_SUBJECT_WIDTH);
        fire.setHeight(DEFAULT_SUBJECT_HEIGHT);
        fire.setImage("fire", context);
        fire.addScript("on enter play fire");
        page.addShape(fire);

        Shape actionPrompt = new Shape("firePrompt");
        actionPrompt.setTextFlag(true);
        actionPrompt.setTextSize(DEFAULT_PROMPT_TEXT_SIZE);
        actionPrompt.setText("Eek! Fire room. Run away!");
        actionPrompt.setX(DEFAULT_PROMPT_X);
        actionPrompt.setY(DEFAULT_PROMPT_Y);
        page.addShape(actionPrompt);

        Shape door = new Shape("fireExit");
        door.setSelectable(true);
        door.setX(DEFAULT_DOOR_X);
        door.setY(DEFAULT_DOOR_Y);
        door.addScript("on click goto " + SCENE_MYSTIC_BUNNY);
        page.addShape(door);

        Shape carrot = new Shape("carrot");
        carrot.setMovable(true);
        carrot.setSelectable(true);
        carrot.setX(DEFAULT_DOOR_X + carrot.getWidth() + DEFAULT_SHAPE_PADDING);
        carrot.setY(DEFAULT_DOOR_Y);
        carrot.setImage("carrot", context);
        page.addShape(carrot);

        return page;
    }

    private Page buildMysticPage() {
        Page page = new Page(SCENE_MYSTIC_BUNNY);

        Shape mysticBunny = new Shape("mysticBunny");
        mysticBunny.setSelectable(true);
        mysticBunny.setX(DEFAULT_SUBJECT_X);
        mysticBunny.setY(DEFAULT_SUBJECT_Y);
        mysticBunny.setWidth(DEFAULT_SUBJECT_WIDTH);
        mysticBunny.setHeight(DEFAULT_SUBJECT_HEIGHT);
        mysticBunny.setImage("mystic", context);
        mysticBunny.addScript("on click hide carrot play munching");
        mysticBunny.addScript("on enter show door2");
        page.addShape(mysticBunny);

        Shape actionPrompt = new Shape("mysticPrompt");
        actionPrompt.setTextFlag(true);
        actionPrompt.setTextSize(DEFAULT_PROMPT_TEXT_SIZE);
        actionPrompt.setText("Mystic Bunny - Rub my tummy for a big surprise!");
        actionPrompt.setX(DEFAULT_PROMPT_X);
        actionPrompt.setY(DEFAULT_PROMPT_Y);
        page.addShape(actionPrompt);

        Shape door = new Shape("mysticDoor");
        door.setSelectable(true);
        door.setX(DEFAULT_DOOR_X);
        door.setY(DEFAULT_DOOR_Y);
        door.addScript("on click goto page1");
        page.addShape(door);

        return page;
    }

    private void buildStartPage(Game game) {
        if (game == null) return;

        Page startPage = game.getStartPage();
        Shape welcomeText = new Shape("welcomeText");
        welcomeText.setTextFlag(true);
        welcomeText.setTextSize(DEFAULT_PROMPT_TEXT_SIZE * 2);
        welcomeText.setText("Bunny World!");
        welcomeText.setX(DEFAULT_SUBJECT_X);
        welcomeText.setY(DEFAULT_SUBJECT_Y);
        startPage.addShape(welcomeText);

        Shape actionPrompt = new Shape("welcomePrompt");
        actionPrompt.setTextFlag(true);
        actionPrompt.setTextSize(DEFAULT_PROMPT_TEXT_SIZE);
        actionPrompt.setText("You are in a maze of twisty little passages, all alike");
        actionPrompt.setTextFlag(true);
        actionPrompt.setX(DEFAULT_PROMPT_X);
        actionPrompt.setY(DEFAULT_PROMPT_Y);
        startPage.addShape(actionPrompt);

        Shape door1 = new Shape("door1");
        door1.setSelectable(true);
        door1.setX(DEFAULT_DOOR_X);
        door1.setY(DEFAULT_DOOR_Y);
        door1.addScript("on click goto " + SCENE_MYSTIC_BUNNY );
        startPage.addShape(door1);

        Shape door2 = new Shape("door2");
        door2.setSelectable(true);
        door2.setX(DEFAULT_DOOR_X + door2.getWidth() + DEFAULT_SHAPE_PADDING);
        door2.setY(DEFAULT_DOOR_Y);
        door2.setHidden(true);
        door2.addScript("on click goto " + SCENE_FIRE);
        startPage.addShape(door2);

        Shape door3 = new Shape("door3");
        door3.setInInventory(false);
        door3.setSelectable(true);
        door3.setX(DEFAULT_DOOR_X + ((door3.getWidth() + DEFAULT_SHAPE_PADDING) * 2));
        door3.setY(DEFAULT_DOOR_Y);
        door3.addScript("on click goto " + SCENE_DEATH_BUNNY );
        startPage.addShape(door3);
    }

    private Page buildVictoryPage() {
        Page page = new Page(SCENE_VICTORY);

        for (int i = 0; i < N_VICTORY_CARROTS; i++) {
            int y_offset = ((i % 2 == 0) ? 0 : DEFAULT_SUBJECT_HEIGHT);
            Shape carrot = new Shape("victoryCarrot" + i);
            carrot.setX(i * DEFAULT_SUBJECT_WIDTH);
            carrot.setY(y_offset);
            carrot.setWidth(DEFAULT_SUBJECT_WIDTH);
            carrot.setHeight(DEFAULT_SUBJECT_HEIGHT);
            carrot.setImage("carrot", context);
            page.addShape(carrot);
        }

        Shape victoryText = new Shape("victoryText");
        victoryText.setTextFlag(true);
        victoryText.setTextSize(DEFAULT_PROMPT_TEXT_SIZE);
        victoryText.setText("You Win! Yay!");
        victoryText.setX(DEFAULT_PROMPT_X);
        victoryText.setY(DEFAULT_PROMPT_Y);
        victoryText.addScript("on enter play hooray");
        page.addShape(victoryText);

        return page;
    }
}
