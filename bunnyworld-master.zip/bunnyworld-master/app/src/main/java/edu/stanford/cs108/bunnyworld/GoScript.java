package edu.stanford.cs108.bunnyworld;

import android.content.Context;

import java.util.List;


public class GoScript extends ShapeScript {

    //parameter: name of a page
    public GoScript(String name, String conditionalName) {
        super(name, conditionalName);
    }

    //parameters: the current game, the current view/activity
    @Override
    public void run(Game game, Context _context) {
        if (game == null) return;
        if (!inInventory()) return;
        Page page = game.getPageByName(name);

        if (page != null) data.setSelectedPage(page);
    }
}
