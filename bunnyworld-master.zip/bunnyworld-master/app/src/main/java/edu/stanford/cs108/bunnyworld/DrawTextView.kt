package edu.stanford.cs108.bunnyworld

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import java.lang.Math.abs

class DrawTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : View(context, attrs, defStyleAttr, defStyleRes) {

    companion object {
        private const val TEXT = "Enter Text"
    }

    private val data = BunnyWorldData.getInstance()

    val shape: Shape = data.selectedShape
    val game: Game = data.selectedGame

    private var drawText = TEXT
    private val drawTextCoordinate = Coordinate()

    var customText: String = ""
        set(value) {
            shape.text = value
            data.updateGame(game)
            field = value
            invalidate()
        }

    // This is to set to ensure the coordinate Y position is fix to the
    // Sample Text height, so that it doesn't move despite of the drawText height change
    // This make it prettier when perform drawing, so the text stay on the baseline regardless
    // of the drawText change height.

    var fontAntialias: Boolean = true
        set(value) {
            field = value
            projectResources.paintText.isAntiAlias = field
            shape.fontAntialias = field
            data.updateGame(game)
            invalidate()
        }

    var fontHinting: Int = Paint.HINTING_ON
        set(value) {
            field = value
            projectResources.paintText.hinting = field
            shape.fontHinting = field
            data.updateGame(game)
            invalidate()
        }

    var fontFakeBold: Boolean = false
        set(value) {
            field = value
            projectResources.paintText.isFakeBoldText = field
            shape.fontFakeBold = field
            data.updateGame(game)
            invalidate()
        }

    var fontUnderline: Boolean = false
        set(value) {
            field = value
            projectResources.paintText.isUnderlineText = field
            shape.fontUnderline = field
            data.updateGame(game)
            invalidate()
        }

    var fontStrikeThrough: Boolean = false
        set(value) {
            field = value
            projectResources.paintText.isStrikeThruText = field
            shape.fontStrikeThrough = field
            data.updateGame(game)
            invalidate()
        }

    var fontFeatureSetting: String = ""
        set(value) {
            field = value
            projectResources.paintText.fontFeatureSettings = field
            shape.fontFeatureSetting = field
            data.updateGame(game)
            invalidate()
        }

    var fontScale: Float = 1.0f
        set(value) {
            field = value
            projectResources.paintText.textScaleX = field
            shape.fontScale = field
            data.updateGame(game)
            invalidate()
        }

    var textSize: Int = 150
        set(value) {
            field = value
            projectResources.paintText.textSize = field.toFloat()
            shape.text_size = field
            data.updateGame(game)
            invalidate()
        }

    var fontSkew: Float = 0f
        set(value) {
            field = value
            projectResources.paintText.textSkewX = field
            shape.fontSkew = field
            data.updateGame(game)
            invalidate()
        }

    var letterSpacing: Float = 0f
        set(value) {
            field = value
            projectResources.paintText.letterSpacing = field
            shape.letterSpacing = field
            data.updateGame(game)
            invalidate()
        }

    var customStyle: Paint.Style = Paint.Style.FILL
        set(value) {
            field = value
            projectResources.paintText.style = field
            shape.customStyle = field
            data.updateGame(game)
            invalidate()
        }


    var typeFace: Typeface = Typeface.DEFAULT
        set(value) {
            field = value
            projectResources.paintText.typeface = field
            shape.typeFace = field
            data.updateGame(game)
            invalidate()
        }

    var color: Int = Color.BLACK
        set(value) {
            field = value
            projectResources.paintText.color = field
            shape.color = field
            data.updateGame(game)
            invalidate()
        }

    private val sampleTextBound by lazy {
        val textBound = Rect()
        projectResources.paintText.getTextBounds(TEXT, 0, TEXT.length, textBound)
        textBound
    }

    private var originTextBound = calculateOriginTextBound()

    private fun calculateOriginTextBound(): Rect {
        val textBound = Rect()
        projectResources.paintText.getTextBounds(drawText, 0, drawText.length, textBound)
        return textBound
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        drawText = if (customText.isBlank()) TEXT else customText
        originTextBound = calculateOriginTextBound()

        drawTextCoordinate.x = width / 2f

        drawTextCoordinate.y = height / 2f - originTextBound.exactCenterY()

        data.updateGame(game)
        canvas.drawText(drawText, drawTextCoordinate.x, drawTextCoordinate.y, projectResources.paintText)
        canvas.drawPoint(drawTextCoordinate.x, drawTextCoordinate.y, projectResources.paintRed)

        //////////////////////////////////////////////////////////////////////////////
        // Fix the draw line per the full height of the text using the Sample Text  //
        //////////////////////////////////////////////////////////////////////////////
        canvas.drawLine(0f, 0f, width.toFloat(), 0f, projectResources.paintLight)
        canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, projectResources.paintLight)
        canvas.drawLine(
            0f, height / 2f - sampleTextBound.calculateCenterY(),
            width.toFloat(),
            height / 2f - sampleTextBound.calculateCenterY(),
            projectResources.paintLight
        )
        canvas.drawLine(
            0f,
            height / 2f + sampleTextBound.calculateCenterY(),
            width.toFloat(),
            height / 2f + sampleTextBound.calculateCenterY(),
            projectResources.paintLight
        )
        canvas.drawLine(0f, height.toFloat(), width.toFloat(), height.toFloat(), projectResources.paintLight)
    }

    private fun Rect.calculateCenterY(): Float {
        return kotlin.math.abs((bottom - top) / 2f)
    }

    private fun Rect.calculateCenterX(): Float {
        return kotlin.math.abs((right - left) / 2f)
    }

    class Coordinate(var x: Float = 0f, var y: Float = 0f)
}
