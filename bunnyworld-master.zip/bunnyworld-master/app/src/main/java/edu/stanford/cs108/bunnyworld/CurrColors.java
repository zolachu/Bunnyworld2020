package edu.stanford.cs108.bunnyworld;
import android.graphics.Color;

class CurrColors {

    int curr_color;

    private static final CurrColors ourInstance = new CurrColors();

    static CurrColors getInstance() {
        return ourInstance;
    }

    private CurrColors() {
    }

    public void setCurrColor(int color){
        curr_color = color;
    }

    public int getCurrColor(){
        return curr_color;
    }

}
