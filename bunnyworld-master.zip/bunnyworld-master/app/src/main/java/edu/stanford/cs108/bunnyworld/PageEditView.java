package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.math.MathUtils;

public class PageEditView extends View {
    private final BunnyWorldData data = BunnyWorldData.getInstance();
    private int width, height, page_area_height;
    private Game game;
    private Page currentPage;
    private Shape selectedShape;

    public PageEditView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        currentPage = data.getSelectedPage();
        game = data.getSelectedGame();
        selectedShape = data.getSelectedShape();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        width = w;
        height = h;
        page_area_height = (int) (height * GamePlayView.PAGE_AREA_HEIGHT_RATIO);
        setMinimumHeight(page_area_height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        currentPage.drawAllShapes(canvas, getContext());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                selectedShape = currentPage.getShapeAt(event.getX(), event.getY());

                currentPage.setShapesHovered(false);
                // Highlight the selected shape
                if (selectedShape != null) selectedShape.setHovered(true);

                // Notify page editor activity to enable delete shape button for selected shape
                data.setSelectedShape(selectedShape);
                ((PageEditActivity)getContext()).selectedShapeUpdated();
                break;
            case MotionEvent.ACTION_MOVE:
                if (selectedShape == null) break;

                float y = event.getY();
                // Center the shape on touch coordinates and ensure it can only be moved within
                // page boundary.
                selectedShape.setX(MathUtils.clamp(
                        event.getX() - selectedShape.getWidth() / 2,
                        0,
                        width - selectedShape.getWidth()
                ));

                selectedShape.setY(MathUtils.clamp(
                        y - selectedShape.getHeight() / 2,
                        0,
                        height - selectedShape.getHeight()
                ));

                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                invalidate();
                if (selectedShape != null) data.updateGame(game);
                break;
        }

        return true;
    }
}
