package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.List;

public class PageEditActivity extends AppCompatActivity {
    private BunnyWorldData data;
    private Game game;
    private Page page;
    private ArrayAdapter shapesAdapter;
    private boolean isOnlyPage;
    private boolean isPreviewMode = false;
    private PageEditView pageView;
    private ImageButton deleteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        data = BunnyWorldData.getInstance();
        // Ensure we don't persist selected shape from another activity
        data.setSelectedShape(null);
        game = data.getSelectedGame();
        page = data.getSelectedPage();
        isOnlyPage = game.getNumPages() == 1;

        setTitle(getString(R.string.page_editor_title) + " - " + page.getName());
        setContentView(R.layout.activity_page_edit);

        pageView = findViewById(R.id.page_view);

        deleteBtn = findViewById(R.id.delete_shape);
        deleteBtn.setOnClickListener(this::deleteSelectedShape);
        selectedShapeUpdated(); // Enables delete button if there is a selected shape

        ImageButton addBtn = findViewById(R.id.add_shape);
        addBtn.setOnClickListener((view) -> newShapeDialog());

        ListView shapeListView = findViewById(R.id.list_view);
        shapeListView.setEmptyView(findViewById(R.id.empty));

        final List<Shape> shapes = page.getShapes();
        shapesAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                shapes
        );
        shapesAdapter.notifyDataSetChanged();
        shapeListView.setAdapter(shapesAdapter);

        shapeListView.setOnItemClickListener((parent, view, position, viewId) -> {
            data.setSelectedShape(shapes.get(position));
            Intent intent = new Intent(this, ShapeEditActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.page_edit_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.edit:
                editDialog();
                break;
            case R.id.view:
                togglePreviewMode();
                break;
            case R.id.delete:
                deleteConfirmationDialog();
                break;
            case R.id.back:
                Intent intent = new Intent(this, GameEditActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.delete);

        // Prevent deleting the only page, a game needs at least one page
        if (!isOnlyPage) {
            item.setEnabled(true);
            item.getIcon().setAlpha(255);
        } else {
            // disabled
            item.setEnabled(false);
            item.getIcon().setAlpha(130);
        }

        return true;
    }

    private void deleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.page_delete_title);
        builder.setMessage(R.string.page_delete_message);
        builder.setCancelable(true);
        builder.setPositiveButton(R.string.dialog_positive_btn, (dialog, which) -> {
            Page startPage = game.getStartPage();
            page.clearShapes();
            game.removePage(page);
            // Ensure we always have a start page
            if (startPage == null || startPage.equals(page)) {
                game.setStartPage(game.getPages().get(0));
            }
            data.setSelectedPage(null);
            data.updateGame(game);
            this.finish();
        });
        builder.setNegativeButton(R.string.dialog_negative_btn, (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    private void editDialog() {
        final View layout = getLayoutInflater().inflate(R.layout.dialog_page_edit, null);
        final CheckBox startPage = layout.findViewById(R.id.start_page);
        final EditText editText = layout.findViewById(R.id.name_edit);
        final Spinner colorsDropdown = layout.findViewById(R.id.colors_spinner);

        ArrayAdapter<String> spinner_adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.colors_array)
        );
        spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        colorsDropdown.setAdapter(spinner_adapter);

        editText.setText(page.getName());
        startPage.setChecked(game.getStartPage().equals(page));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.page_edit);
        builder.setCancelable(true);
        builder.setView(layout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            boolean isStartPage = startPage.isChecked();
            String name = editText.getText().toString();
            if (name.isEmpty() ||
                    (!page.getName().equalsIgnoreCase(name) && !game.isUniquePageName(name))
            ) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            page.setName(name);
            if (isStartPage) game.setStartPage(page);

            String selectedColor = (String) colorsDropdown.getSelectedItem();
            int color = Color.WHITE;
            switch (selectedColor) {
                case "Red":
                    color = Color.RED;
                    break;
                case "Blue":
                    color = Color.BLUE;
                    break;
                case "Green":
                    color = Color.GREEN;
                    break;
                case "Magenta":
                    color = Color.MAGENTA;
                    break;
                case "Yellow":
                    color = Color.YELLOW;
                    break;
                case "Cyan":
                    color = Color.CYAN;
                    break;
                default:
            }
            page.setBackgroundFill(color);
            pageView.invalidate();

            data.updateGame(game);
            setTitle(getString(R.string.page_editor_title) + " - " + page.getName());
            dialog.dismiss();
        });
    }

    public void paste(View view) {
        page.paste();
        pageView.invalidate();
        shapesAdapter.notifyDataSetChanged();
        data.updateGame(game);
    }

    private void newShapeDialog() {
        final View nameLayout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = nameLayout.findViewById(R.id.name_edit);
        editText.setText(getString(R.string.shape_default_name, page.getNumShapes() + 1));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.shape_new);
        builder.setCancelable(true);
        builder.setView(nameLayout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();
            if (name.isEmpty() && !game.isUniqueShapeName(name)) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            page.addShape(new Shape(name));
            data.updateGame(game);
            shapesAdapter.notifyDataSetChanged();
            dialog.dismiss();
        });
    }

    public void deleteSelectedShape(View view) {
        Shape shape = data.getSelectedShape();
        if (shape == null) return;

        page.removeShape(shape);
        data.setSelectedShape(null);
        pageView.invalidate();
        shapesAdapter.notifyDataSetChanged();
        data.updateGame(game);
    }

    private void togglePreviewMode() {
        isPreviewMode = !isPreviewMode;
        pageView.setVisibility(isPreviewMode ? View.VISIBLE : View.GONE);
    }

    public void selectedShapeUpdated() {
        Shape shape = data.getSelectedShape();
        deleteBtn.setEnabled(shape != null);
    }
}
