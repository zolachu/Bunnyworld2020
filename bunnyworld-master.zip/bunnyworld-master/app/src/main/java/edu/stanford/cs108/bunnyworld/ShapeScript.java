package edu.stanford.cs108.bunnyworld;

import android.content.Context;

public class ShapeScript {
    protected BunnyWorldData data = BunnyWorldData.getInstance();
    public String name;
    public String conditionalName;

    //parameter: a name that the ShapeScript action is associated with
    public ShapeScript(String name, String conditionalName) {
        this.name = name;
        this.conditionalName = conditionalName;
    }

    //parameters: the current game, the current view/activity
    public void run(Game game, Context context) {
        //superclass placeholder for subclass implementation
    }
    // Gets the name of the object that the script refers to
    public String getName(){
        return name;
    }

    // Gets the name of the possession that an action condition may reference
    public String getConditionalName() {
        return conditionalName;
    }

    //checks if conditional shape name is in inventory area
    public boolean inInventory() {
        if(conditionalName.isEmpty()) {
            return true;
        } else {
            return data.getSelectedGame().inPossession(conditionalName);
        }
    }

    public ShapeScript clone() {
        ShapeScript clone = new ShapeScript(name, conditionalName);
        return clone;
    }
}
