package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;


class ShapePreviewDraw extends View{
    int width;
    int height;
    Shape shape;

    public ShapePreviewDraw(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        width = w;
        height = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (shape != null){
            // Store previous values
            float x = shape.getX();
            float y = shape.getY();
            shape.setX(0);
            shape.setY(0);

            if (shape.getTextFlag()) {
                float canvas_height = canvas.getHeight();
                float canvas_width = shape.getWidth();
                String shape_text =  shape.getText();
                Rect text_bounding_box = new Rect();
                Paint paint = new Paint();
                paint.setTextSize(shape.text_size);
                paint.getTextBounds(shape_text, 0 , shape_text.length(), text_bounding_box);
                float height = text_bounding_box.height();
                float width = text_bounding_box.width();
                float max = Math.max(height/canvas_height, width/canvas_width);
                max = Math.max(1, max);
                int shape_text_size = shape.text_size;
                int preview_size = (int) Math.floor(shape.text_size / max);
                shape.text_size = preview_size;
                shape.setX(0);
                shape.setY(height);
                shape.draw(canvas, getContext());
                shape.setTextSize(shape_text_size);
            } else{
                shape.draw(canvas, getContext());
            }

            // Restore previous values
            shape.setX(x);
            shape.setY(y);
        } else {
            //canvas.drawColor(Color.BLACK);
            return;
        }
    }

    public void setShape(Shape shape_init){
        shape = shape_init;
        invalidate();
    }

    public void redraw(){
        invalidate();
    }

}
