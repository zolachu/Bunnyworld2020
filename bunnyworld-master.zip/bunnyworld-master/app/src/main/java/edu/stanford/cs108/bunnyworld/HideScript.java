package edu.stanford.cs108.bunnyworld;

import android.content.Context;

import java.util.List;

public class HideScript extends ShapeScript{


    //parameter: a shape name that the HideScript action is associated with
    public HideScript(String shapeName, String conditionalName) {
        super(shapeName, conditionalName);
    }

    //parameters: list of all shapes in the game, the current view/activity,
    //directly changes the specified shape's state to hidden
    @Override
    public void run(Game game, Context _context) {
        if (game == null) return;
        if (!inInventory()) return;

        Shape shape = game.getShapeByName(name);
        if (shape != null) shape.setHidden(true);
    }
}
