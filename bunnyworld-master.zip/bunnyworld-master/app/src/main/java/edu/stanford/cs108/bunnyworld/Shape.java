package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.text.TextPaint;

import androidx.core.math.MathUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.regex.*;
import java.util.stream.Collectors;

public class Shape {
    private static final int DEFAULT_X = 0;
    private static final int DEFAULT_Y = 0;
    private static final int DEFAULT_WIDTH = 200;
    private static final int DEFAULT_HEIGHT = 200;
    private static final boolean DEFAULT_SELECTABLE = false;
    private static final String DEFAULT_SCRIPT = "";
    private static final int HIGHLIGHT_OUTLINE_WIDTH = 5;
    private static final int DEFAULT_TEXT_SIZE = 50;
    private static final int SHRINK_FACTOR = 2;
    private static final int GROWTH_FACTOR = 4;
    private static final int UPPER_X = 2350;
    private static final int UPPER_Y = 775;

    private String name;

    // Values for bounding rectangle
    private float x;
    private float y;
    private float width;
    private float height;

    // Things to-draw...
    private transient BitmapDrawable image;
    private String image_name = ""; // Init to empty string
    private String text = "";
    public int text_size = DEFAULT_TEXT_SIZE;

    private ResourceList resources = ResourceList.getInstance();

    // Shape script
    // set of clauses separated by whitespace, with semicolon after
    // Structure of script:
    // Trigger <name?><actions>
    // i.e. on drop <shapeName> <actions>
    private String shape_script;

    // Arrays of ShapeScript objects for each type of action
    private transient ArrayList<ShapeScript> onclick_actions = new ArrayList<ShapeScript>();
    private transient ArrayList<ShapeScript> onenter_actions = new ArrayList<ShapeScript>();
    private transient HashMap<String, ArrayList<ShapeScript>> ondrop_actions = new HashMap<String, ArrayList<ShapeScript>>();

    // If set to true, only visible in editor
    private boolean hidden = false;
    private boolean movable = false;
    // Track which shape is being hovered, turn on rect
    private boolean hovered = false;
    private boolean selectable = false;
    private boolean in_inventory = false;

    // Paints for drawing selectable box/default rectangle
    private transient Paint grey_paint;
    private transient Paint green_select_paint;
    private transient Paint black_text_paint;
    private transient Canvas canvas;

    //For rich text support extension
    public boolean fontAntialias = true;
    public int fontHinting = Paint.HINTING_ON;
    public String fontFeatureSetting = "";
    public boolean fontFakeBold = false;
    public float fontScale = 1.0f;
    public float fontSkew = 0f;
    public float letterSpacing = 0f;
    public Paint.Style customStyle = Paint.Style.FILL;
    public Typeface typeFace = Typeface.DEFAULT;
    public boolean fontStrikeThrough = false;
    public boolean fontUnderline = false;
    public int color = Color.BLACK;
    private boolean isText = false;

    private float oldY;
    private float oldX;
    private float oldHeight;
    private float oldWidth;
    private boolean oldSelectable;
    private boolean oldMovable;
    private boolean oldHidden;
    private String oldName = "";
    private String oldScript;
    private transient BitmapDrawable oldImage;
    private String oldImageName;
    private String oldText;
    private int oldTextSize;


    private boolean oldFontAntialias = true;
    private int oldFontHinting = Paint.HINTING_ON;
    private String oldFontFeatureSetting = "";
    private boolean oldFontFakeBold = false;
    private float oldFontScale = 1.0f;
    private float oldFontSkew = 0f;
    private float oldLetterSpacing = 0f;
    private Paint.Style oldCustomStyle = Paint.Style.FILL;
    private Typeface oldTypeFace = Typeface.DEFAULT;
    private boolean oldFontStrikeThrough = false;
    private boolean oldFontUnderline = false;
    private int oldColor = Color.BLACK;
    private boolean oldIsText = false;


    // Initialize paints
    private void initializePaints() {
        // Light grey paint for default rect
        grey_paint = new Paint();
        grey_paint.setColor(Color.GRAY);
        grey_paint.setStyle(Paint.Style.FILL);

        // Bright green outline box for selectable
        green_select_paint = new Paint();
        green_select_paint.setColor(Color.GREEN);
        green_select_paint.setStyle(Paint.Style.STROKE);
        green_select_paint.setStrokeWidth(HIGHLIGHT_OUTLINE_WIDTH);

        // Text paint
        black_text_paint = new TextPaint();
        black_text_paint.setColor(Color.BLACK);
        black_text_paint.setTextSize(text_size);
    }

    public Shape(String name) {
        this(name, DEFAULT_X, DEFAULT_Y, DEFAULT_WIDTH, DEFAULT_HEIGHT, DEFAULT_SELECTABLE);
    }

    // Constructor
    public Shape(String name_init, float x_init, float y_init, float width_init, float height_init, boolean selectable_init){
        this(name_init, x_init, y_init, width_init, height_init, selectable_init, DEFAULT_SCRIPT);
    }

    public Shape(
            String name_init,
            float x_init,
            float y_init,
            float width_init,
            float height_init,
            boolean selectable_init,
            String script) {
        name = name_init;
        // Set coordinates
        x = x_init;
        y = y_init;
        width = width_init;
        height = height_init;
        selectable = selectable_init;
        shape_script = script;
        text_size = DEFAULT_TEXT_SIZE;
        initializePaints();
        // Initialize arrays of script actions
        parseScript(); // IMPORTANT Must be called after shape_script is initialized
    }

    public Shape (String newShapeName, Shape shape) {
        name = newShapeName;
        y = shape.getY();
        x = shape.getX();
        height = shape.getHeight();
        width = shape.getWidth();
        selectable = shape.getSelectable();
        shape_script = shape.getScriptText();
        movable = shape.isMovable();
        hidden = shape.getHidden();
        image_name = shape.getImageName();
        image = shape.getImage();
        text = shape.getText();
        text_size = shape.getTextSize();
        onclick_actions = shape.cloneScripts(shape.getRawOnClicks());
        onenter_actions = shape.cloneScripts(shape.getRawOnEnters());
        HashMap<String, ArrayList<ShapeScript>> dropScripts = new HashMap<String, ArrayList<ShapeScript>>();
        for(String key : shape.getRawOnDrops().keySet()) {
            ArrayList<ShapeScript> scripts = shape.cloneScripts(shape.getRawOnDrops().get(key));
            dropScripts.put(key, scripts);
        }
        ondrop_actions = dropScripts;
        initializePaints();
        fontAntialias = shape.getFontAntialias();
        fontHinting = shape.getFontHinting();
        fontFeatureSetting = shape.getFontFeatureSetting();
        fontFakeBold = shape.getFontFakeBold();
        fontScale = shape.getFontScale();
        fontSkew = shape.getFontSkew();
        letterSpacing = shape.getLetterSpacing();
        customStyle = shape.getCustomStyle();
        typeFace = shape.getTypeFace();
        fontStrikeThrough = shape.getFontStrikeThrough();
        fontUnderline = shape.getFontUnderline();
        color = shape.getColor();
        isText = shape.getIsText();
    }

    // GETTERS

    public boolean getFontAntialias() {
        return fontAntialias;
    }
    public int getFontHinting() {
        return fontHinting;
    }
    public String getFontFeatureSetting() {
        return fontFeatureSetting;
    }
    public boolean getFontFakeBold() {
        return fontFakeBold;
    }
    public float getFontScale() {
        return fontScale;
    }
    public float getFontSkew() {
        return fontSkew;
    }
    public float getLetterSpacing() {
        return letterSpacing;
    }
    public Paint.Style getCustomStyle() {
        return customStyle;
    }
    public Typeface getTypeFace() {
        return typeFace;
    }
    public boolean getFontStrikeThrough() {
        return fontStrikeThrough;
    }
    public boolean getFontUnderline() {
        return fontUnderline;
    }
    public int getColor() {
        return color;
    }
    public boolean getIsText() {
        return isText;
    }

    /**
     * Returns a list of all shape script actions.
     * This is deliberately private to avoid providing client access to internal data structures.
     * @return list of shape script actions
     */
    private List<ShapeScript> getAllScriptActions() {
        ArrayList<ShapeScript> actions = new ArrayList<>();
        actions.addAll(onclick_actions);
        actions.addAll(onenter_actions);
        actions.addAll(
                ondrop_actions.values()
                        .stream()
                        .flatMap(Collection::stream)
                        .collect(Collectors.toList())
        );
        return actions;
    }

    public ArrayList<ShapeScript> getRawOnClicks() {
        return onclick_actions;
    }

    public ArrayList<ShapeScript> getRawOnEnters() {
        return onenter_actions;
    }

    public HashMap<String, ArrayList<ShapeScript>> getRawOnDrops() {
        return ondrop_actions;
    }

    // Getters to return list of ShapeScript options
    public ArrayList<String> getOnClickActions() {
        ArrayList<String> actions_list = new ArrayList<>();
        for (ShapeScript script : onclick_actions){
            String action = getScriptType(script);
            String entry = action + script.getName();
            actions_list.add(entry);
        }
        return actions_list;
    }

    public ArrayList<String> getOnEnterActions(){
        ArrayList<String> actions_list = new ArrayList<>();
        for (ShapeScript script : onenter_actions){
            String action = getScriptType(script);
            String entry = action + script.getName();
            actions_list.add(entry);
        }
        return actions_list;
    }

    public ArrayList<String> getOnDropActions(String drop_on) {
        ArrayList<String> actions_list = new ArrayList<>();
        for (ShapeScript script : ondrop_actions.get(drop_on)){
            String action = getScriptType(script);
            String entry = action + script.getName();
            actions_list.add(entry);
        }
        return actions_list;
    }

    private String getScriptType(ShapeScript script){
        String type = script.getClass().getSimpleName();
        switch (type){
            case "ShowScript":
                return "show ";
            case "HideScript":
                return "hide ";
            case "GoScript":
                return "goto ";
            case "PlayScript":
                return "play ";
            case "ShrinkScript":
                return "shrink ";
            case "GrowScript":
                return "grow ";
            case "RandomScript":
                return "random ";
            default:
                return "";
        }
    }

    // Getter for name
    public String getName() {
        return name;
    }

    public String getText(){
        return text;
    }
    public int getTextSize() {
        return text_size;
    }
    public String getScriptText(){
        return shape_script;
    }
    public String getImageName(){
        return image_name;
    }
    public float getHeight() {
        return height;
    }

    public boolean getHovered() {
        return hovered;
    }

    public float getWidth() {
        return width;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public BitmapDrawable getImage() {
        return image;
    }

    public boolean getHidden(){return hidden;}
    public boolean getSelectable(){return selectable;}
    public boolean getInInventory(){return in_inventory;}
    public boolean getTextFlag() {return isText; }
    public Paint getPaint() {return black_text_paint; }
    /**
     * Returns true if the image_name is references a valid image resource.
     * The image_name is also considered valid if null, or empty since it is not a required field
     * for all shape types.
     * @return true if image_name valid, otherwise false
     */
    public boolean hasValidImageName() {
        ResourceList resources = ResourceList.getInstance();
        if (image_name == null || image_name.isEmpty() || resources.hasImage(image_name)) return true;
        BunnyWorldData.getInstance().setValidationErrorMessage(
                "Shape " + name + " image_name references invalid resource name " + image_name
        );

        return false;
    }

    /**
     * Returns true if all script actions reference valid game objects (pages, shapes, resources).
     * @param game associated game instance
     * @return true if all scripts contain valid name references, otherwise false
     */
    public boolean hasValidScriptActions(Game game) {
        if (game == null) return false;
        BunnyWorldData data = BunnyWorldData.getInstance();
        ResourceList resources = ResourceList.getInstance();
        for (ShapeScript action : getAllScriptActions()) {
            String className = action.getClass().getSimpleName();
            switch (className) {
                case "GoScript":
                    if (!game.hasPageName(action.getName())) {
                        data.setValidationErrorMessage(
                            buildInvalidScriptMessage(name, className, "page", action.getName())
                        );
                        return false;
                    }
                    break;
                case "PlayScript":
                    if (!resources.hasSound(action.getName())) {
                        data.setValidationErrorMessage(
                            buildInvalidScriptMessage(name, className, "resource", action.getName())
                        );
                        return false;
                    }
                    break;
                case "GrowScript":
                case "HideScript":
                case "ShowScript":
                case "ShrinkScript":
                    if (!game.hasShapeName(action.getName())) {
                        data.setValidationErrorMessage(
                            buildInvalidScriptMessage(name, className, "shape", action.getName())
                        );
                        return false;
                    }
                    break;
            }
            if (!action.getConditionalName().isEmpty() && !game.hasShapeName(action.getConditionalName())) {
                data.setValidationErrorMessage(
                    buildInvalidScriptMessage(name, className, "conditional possession", action.getConditionalName())
                );
                return false;
            }
        }

        return true;
    }

    private String buildInvalidScriptMessage(String name, String scriptType, String referenceType, String referenceName) {
        return name + " " + scriptType + " action references invalid " + referenceType + " name " + referenceName;
    }

    public boolean isMovable() {
        return movable;
    }


    // SETTERS
    public void setTextSize(int size){
        text_size = size;
        black_text_paint.setTextSize(text_size);
    }

    public void setName(String new_name){
        name = new_name;
    }
    // Setters for image/text
    public void setText(String text_in){
        text = text_in;
    }

    public void setDrawable(String image_name_init, BitmapDrawable image_init){
        image_name = image_name_init;
        if (image_init == null){
        }
        image = image_init;
    }

    // Only set if not already set from local storage
    public void setImage(String name, Context context) {
        resources = ResourceList.getInstance();
        BitmapDrawable image_drawable;
        // Only set image if it isn't being set from a file
        if (!resources.checkLocal(name)) {
            try {
                // get drawable resource ID for given name
                int image_id = context.getResources().getIdentifier(
                        name,
                        "drawable",
                        context.getPackageName()
                );
                // get the actual bitmap resource
                image_drawable = (BitmapDrawable) context.getResources().getDrawable(
                        image_id, context.getApplicationContext().getTheme()
                );
                // Set image on the shape
                setDrawable(name, image_drawable);
            } catch (NullPointerException | Resources.NotFoundException exception) {
                // TODO: provide feedback indicating image resource not found, ignore for now
                return;
            }
        } else {
            image_drawable = loadImageFromStorage(resources.getPath(), image_name, context);
            this.setDrawable(image_name, image_drawable);
            return;
        }
    }
    // Same as in shape, based on https://stackoverflow.com/questions/17674634/saving-and-reading-bitmaps-images-from-internal-memory-in-android
    // Based on top two/three answers
    private BitmapDrawable loadImageFromStorage(String path, String name, Context context) {
        BitmapDrawable d = null;
        String name_full = name + ".jpg";
        try {
            File f=new File(path, name_full);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            d = new BitmapDrawable(context.getResources(), b);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        return d;
    }

    public void resetToDefault(){
        text = "";
        image_name = "";
    }
    // Setters for state of shape
    public void setHidden(boolean hidden_in){
        hidden = hidden_in;
    }

    public void setHovered(boolean choice) {
        hovered = choice;
    }

    public void setMovable(boolean choice) {
        movable = choice;
    }

    public void setSelectable(boolean choice){
        selectable = choice;
    }

    public void setInInventory(boolean choice){
        in_inventory = choice;
    }

    public void setX(float new_x){
        x = new_x;
    }

    public void setY(float new_y){
        y = new_y;
    }

    public void setWidth(float new_width){
        width = new_width;
    }
    public void setHeight(float new_height){
        height = new_height;
    }

    public void setTextFlag(boolean flag) { isText = flag; }

    public void removeImage(){
        image_name = "";
    }

    public void setOnClickActions(ArrayList<ShapeScript> scripts) {
        onclick_actions = scripts;
    }

    public void setOnEnterActions(ArrayList<ShapeScript> scripts) {
        onenter_actions = scripts;
    }

    public void setOnDropActions(HashMap<String, ArrayList<ShapeScript>> scripts) {
        ondrop_actions = scripts;
    }

    public ArrayList<ShapeScript> cloneScripts(ArrayList<ShapeScript> scripts) {
        ArrayList<ShapeScript> clonedScripts = new ArrayList<ShapeScript>();
        for(ShapeScript script : scripts) {
            clonedScripts.add(script.clone());
        }
        return clonedScripts;
    }

    // account for added scripts!
    public void refreshScripts(){
        parseScript();
    }

    public void removeScripts(){
        // Delete all
        shape_script = "";
        parseScript();
    }
    public void addScript(String script){
        if (script.contains("on drop") || script.contains("on enter") || script.contains("on click")){
            shape_script += script + ";";
            parseScript();
        }
    }
    // Check if a click/hover is within the shape's area
    public boolean insideShape(float sel_x, float sel_y){
        if (sel_x >=  x && sel_x <= (x + width) && sel_y >= y && sel_y <= (y + height)){
            // Or change to 'hoverable'?
            return true;
        } else {
            return false;
        }
    }

    // Draw self
    public void draw(Canvas init_canvas, Context context){
        canvas = init_canvas;
        RectF rect = new RectF(x, y, (x + width), (y + height));
        // If both empty, default rect

        if (text.isEmpty() && image_name.isEmpty()){
//            isText = false;
            setTextFlag(false);
            drawDefaultRect(rect);
        } else if (!text.isEmpty()){ // Check text first
            setTextFlag(true);
            drawText();
        } else { // Draw image
            // Image is always set here, it should never be null!
            if (image == null) {
                setImage(image_name, context); // Lazy retrieval of image resource
            }
            if (image == null) setImage(image_name, context); // Lazy retrieval of image resource
            setTextFlag(false);
            drawImage(rect, canvas); // Placeholder
        }

        // If hovered, draw bounding box last so it appears on top of the shape
        if (selectable && hovered) drawBoundingBox(rect);
    }


    // Draws a bounding box around the shape
    private void drawBoundingBox(RectF rect){
        canvas.drawRect(rect, green_select_paint);
    }
    // Default grey rectangle
    private void drawDefaultRect(RectF rect){
        canvas.drawRect(rect, grey_paint);
    }
    // Draws text, in black size 20 paint at coordinate
    private void drawText(){

        // ZOLA rich text support extension
        black_text_paint.setTextSize(text_size);
        black_text_paint.setAntiAlias(fontAntialias);
        black_text_paint.setTextScaleX(fontScale);
        black_text_paint.setUnderlineText(fontUnderline);
        black_text_paint.setHinting(fontHinting);
        black_text_paint.setTextSkewX(fontSkew);
        black_text_paint.setColor(color);
        black_text_paint.setLetterSpacing(letterSpacing);
        black_text_paint.setStrikeThruText(fontStrikeThrough);
        black_text_paint.setTypeface(typeFace);
        black_text_paint.setStyle(customStyle);
        black_text_paint.setFakeBoldText(fontFakeBold);

        canvas.drawText(text, x, y, black_text_paint);
    }

    // Placeholder!
    private void drawImage(RectF rect, Canvas canvas){
        Bitmap init = image.getBitmap();
        canvas.drawBitmap(init, null, rect, null); // Draw scaled bitmap?
    }

    // This turns the string of shapescript actions into lists of various
    // ShapeScript objects to be executed
    // This turns the string of shapescript actions into lists of various
    // ShapeScript objects to be executed
    private void parseScript(){
        // Do nothing if null or empty shape_script
        if (shape_script == null || shape_script.isEmpty()) return;

        Pattern ondrop_name = Pattern.compile("(?:on drop )([a-zA-Z0-9]*)(?:\\s)");
        // Separate into clauses
        String[] script_text = shape_script.split(";");

        // Parse each clause
        for (String clause : script_text){
            String reduced = clause;
            String conditionalName = "";
            if(clause.contains("if possess")) {
                conditionalName = clause.substring(clause.indexOf("if possess")+11);
                // Remove the conditional text...
                reduced = clause.replace(clause.substring(clause.indexOf("if possess")), "");
            }

            // Check which type of trigger it contains
            if (clause.contains("on click")){ // On click
                // Remove the trigger text...
                String reduce_clause = reduced.replace("on click", "");
                // Create a new ArrayList to hold the actions:
                ArrayList<ShapeScript> on_click = findActions(reduce_clause, conditionalName);
                onclick_actions.addAll(on_click);
            } else if (clause.contains("on enter")){ // On enter
                // Remove the trigger text...
                String reduce_clause = reduced.replace("on enter", "");
                // Create a new ArrayList to hold the actions:
                ArrayList<ShapeScript> on_enter = findActions(reduce_clause, conditionalName);
                onenter_actions.addAll(on_enter);
            } else if (clause.contains("on drop")){ // On drop
                // Remove the trigger text
                // Get the shape name
                Matcher ondrop_matcher = ondrop_name.matcher(clause);
                ondrop_matcher.find();
                String name = ondrop_matcher.group(1);
                // Remove the trigger and the name of the shape
                String remove_trigger = reduced.replace("on ", "");
                String reduced_clause = reduced.replaceFirst(name, "");
                // Create a new ArrayList to hold the actions:
                ArrayList<ShapeScript> on_drop = findActions(reduced_clause, conditionalName);
                // Add to dictionary with key 'name'
                ondrop_actions.put(name, on_drop);
            } else {
                return;
            }
        }
    }


    // Helper for parseScripts()
    private ArrayList<ShapeScript> findActions(String action_list, String conditionalShape) {
        // Find actions
        ArrayList<ShapeScript> actions = new ArrayList<>();

        Pattern action_patt = Pattern.compile("(goto |play |hide |show |shrink |grow |random )([a-zA-Z0-9_]+)(?:\\s)*");
        // This matcher finds action + name pairs
        // Group(1) is the name of the action, group(2) is the name of whatever page or shape it
        // takes as an argument
        Matcher matcher = null;
        if (action_list.contains("goto ") || action_list.contains("play ") || action_list.contains("hide ") || action_list.contains("show") ||
                action_list.contains("shrink ") || action_list.contains("grow ") || action_list.contains("random ")){
            matcher = action_patt.matcher(action_list);
        }
        // Add all actions to ArrayList
        if (matcher != null){
            while(matcher.find()){
                String action_name = matcher.group(1);
                if (action_name == null) continue;

                switch (action_name.trim()) {
                    case "goto":
                        GoScript new_goto = new GoScript(matcher.group(2), conditionalShape);
                        actions.add(new_goto);
                        break;
                    case "play":
                        PlayScript new_play = new PlayScript(matcher.group(2), conditionalShape);
                        actions.add(new_play);
                        break;
                    case "hide":
                        HideScript new_hide = new HideScript(matcher.group(2), conditionalShape);
                        actions.add(new_hide);
                        break;
                    case "show":  // show
                        ShowScript new_show = new ShowScript(matcher.group(2), conditionalShape);
                        actions.add(new_show);
                        break;
                    case "shrink": //shrink
                        ShrinkScript new_shrink = new ShrinkScript(matcher.group(2), conditionalShape);
                        actions.add(new_shrink);
                        break;
                    case "grow": //grow
                        GrowScript new_grow = new GrowScript(matcher.group(2), conditionalShape);
                        actions.add(new_grow);
                        break;
                    case "random": //random location
                        RandomScript new_random = new RandomScript(matcher.group(2), conditionalShape);
                        actions.add(new_random);
                        break;
                    default:
                        break;
                }
            }
        }
        return actions;
    }

    /**
     * Go through and execute all the actions associated with onClick trigger.
     * Sets selectedPage in BunnyWorldData singleton if a goto <page> action is run.
     * The caller should check the value of selectedPage in the singleton data class to detect a
     * page change.
     * @param game the current game
     * @param context the current view/activity
     */
    public void onClick(Game game, Context context) {
        // Go through onClick actions and run
        for (ShapeScript action : onclick_actions){
            action.run(game, context);
        }
    }

    /**
     * Go through and execute all the actions associated with onEnter trigger.
     * Sets selectedPage in BunnyWorldData singleton if a goto <page> action is run.
     * The caller should check the value of selectedPage in the singleton data class to detect a
     * page change.
     * @param game the current game
     * @param context the current view/activity
     */
    public void onEnter(Game game, Context context) {
        // Go through all onenter_actions and run!
        for (ShapeScript action : onenter_actions){
            action.run(game, context);
        }
    }

    public String getScripts(){
        return shape_script;
    }


    /**
     * Go through and execute all the actions associated with onDrop trigger for given shape name.
     * Sets selectedPage in BunnyWorldData singleton if a goto <page> action is run.
     * The caller should check the value of selectedPage in the singleton data class to detect a
     * page change.
     * @param shape_name selected shape name
     * @param game the current game
     * @param context the current view/activity
     */
    public void onDrop(String shape_name, Game game, Context context) {
        // If contained as a key, get array list
        if (ondrop_actions.containsKey(shape_name)){
            ArrayList<ShapeScript> actions = ondrop_actions.get(shape_name);
            if (actions == null) return;

            // Execute all the actions
            for (ShapeScript action : actions){
                action.run(game, context);
            }
        }

    }

    public boolean inOnDrop(String shape_name) {
        if (ondrop_actions.containsKey(shape_name)) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return name;
    }

    public static Shape JSONtoShape(String JSONstring) {
        Gson gsonBuilder = new GsonBuilder().create();

        Shape shape = gsonBuilder.fromJson(JSONstring, Shape.class);
        shape.onclick_actions = new ArrayList<>();
        shape.onenter_actions = new ArrayList<>();
        shape.ondrop_actions = new HashMap<>();
        shape.initializePaints();
        shape.parseScript();

        return shape;
    }

    //updates shape's backup save state for future undo
    public void saveBackup(float x, float y, float height, float width, boolean selectable,
                           boolean movable, boolean hidden, String name, String script,
                           BitmapDrawable image, String image_name, String text, int text_size,
                           boolean fontAntialias, int fontHinting, String fontFeatureSetting,
                           boolean fontFakeBold, float fontScale, float fontSkew, float letterSpacing,
                           Paint.Style customStyle, Typeface typeFace, boolean fontStrikeThrough,
                           boolean fontUnderline, int color, boolean isText) {
        oldY = y;
        oldX = x;
        oldHeight = height;
        oldWidth = width;
        oldSelectable = selectable;
        oldMovable = movable;
        oldHidden = hidden;
        oldName = name;
        oldScript = script;
        oldImage = image;
        oldImageName = image_name;
        oldText = text;
        oldTextSize = text_size;

        oldFontAntialias = fontAntialias;
        oldFontHinting = fontHinting;
        oldFontFeatureSetting = fontFeatureSetting;
        oldFontFakeBold =fontFakeBold ;
        oldFontScale = fontScale;
        oldFontSkew = fontSkew;
        oldLetterSpacing = letterSpacing;
        oldCustomStyle = customStyle;
        oldTypeFace = typeFace;
        oldFontStrikeThrough = fontStrikeThrough;
        oldFontUnderline = fontUnderline;
        oldColor = color;
        oldIsText = isText;
    }

    //restores shape state to last undo state
    public void undo() {
        if(!oldName.isEmpty()) {
            y = oldY;
            x = oldX;
            height = oldHeight;
            width = oldWidth;
            selectable = oldSelectable;
            movable = oldMovable;
            hidden = oldHidden;
            name = oldName;
            shape_script = oldScript;
            image = oldImage;
            image_name = oldImageName;
            text = oldText;
            text_size = oldTextSize;
    
            fontAntialias = oldFontAntialias;
            fontHinting = oldFontHinting;
            fontFeatureSetting = oldFontFeatureSetting;
            fontFakeBold = oldFontFakeBold;
            fontScale = oldFontScale;
            fontSkew = oldFontSkew;
            letterSpacing = oldLetterSpacing;
            customStyle = oldCustomStyle;
            typeFace = oldTypeFace;
            fontStrikeThrough = oldFontStrikeThrough;
            fontUnderline = oldFontUnderline;
            color = oldColor;
            isText = oldIsText;
        }
    }
    
    //shrinks shape slightly
    public void shrink() {
        height = height/SHRINK_FACTOR + height/GROWTH_FACTOR;
        width = width/SHRINK_FACTOR + width/GROWTH_FACTOR;
    }

    //expands shape slightly
    public void grow() {
        height = height + height/GROWTH_FACTOR;
        width = width + width/GROWTH_FACTOR;
    }

    //moves shape to random location on page
    public void random() {
        int randomX = (int)(Math.random()*(UPPER_X+1));
        int randomY = (int)(Math.random()*(UPPER_Y+1));;

        setX(MathUtils.clamp(
                randomX - width / 2,
                0,
                UPPER_X - width
        ));
        setY(MathUtils.clamp(
                randomY - height / 2,
                0,
                UPPER_Y - height
        ));
    }
}
