package edu.stanford.cs108.bunnyworld;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;

public class ExportFile extends AppCompatActivity {
    private BunnyWorldData data = BunnyWorldData.getInstance();

    private EditText et_email;
    private EditText et_subject;
    private EditText et_message;

    private Button Send;

    private String email;
    private String subject;
    private String message;

    private Uri URI = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export_file);
        et_email = findViewById(R.id.et_to);
        et_subject = findViewById(R.id.et_subject);
        et_message = findViewById(R.id.et_message);
        File export = data.getExportFile();
        try {
            URI = FileProvider.getUriForFile(
                    ExportFile.this,
                    "edu.stanford.cs108.bunnyworld.FileProvider",
                    export
            );
        } catch (IllegalArgumentException e) {
            Log.e("File Selector",
                    "The selected file can't be shared: " + export.toString());
        }
        Send = findViewById(R.id.bt_send);
        //send button listener
        Send.setOnClickListener(v -> sendEmail());
    }

    public void sendEmail() {
        try {
            email = et_email.getText().toString();
            subject = et_subject.getText().toString();
            message = et_message.getText().toString();

            final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
            emailIntent.setType("plain/text");
            emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,new String[] { email });
            emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,subject);

            if (URI != null) {
                emailIntent.putExtra(Intent.EXTRA_STREAM, URI);
            }
            emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, message);

            this.startActivity(Intent.createChooser(emailIntent,"Sending email..."));
        } catch (Throwable t) {
            Toast.makeText(this, R.string.request_failed + t.toString(),Toast.LENGTH_LONG).show();
            Log.e("File Selector", "There was an error trying to put the file as an attachment: " + t.getMessage());
        }
    }
}
