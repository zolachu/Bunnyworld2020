package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import static android.graphics.Bitmap.Config.ARGB_8888;

// Draw the LSystem!
// Also - save to bitmap

public class DrawingView extends View {

    LSystem system;

    int color_chosen = -1;

    // Actual dimensions of the view
    int viewWidth;
    int viewHeight;

    // Default constructor
    public DrawingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }


    // Set up L-System here!
    public void buildSystem(String name){ // Custom
        system = new LSystem();

        if (color_chosen == -1){
            system.setPaint(Color.BLUE);
        } else {
            system.setPaint(color_chosen);
        }

        int init_x = viewWidth/2;
        int init_y = viewHeight/2;

        switch (name){
            case "Sierpinski Square":
                system.setAxiom("F+XF+F+XF");
                system.setRule('X', "XF-F+F-XF+F+XF-F+F-X");
                system.setValues(10, init_x, init_y * 1.75, 0, 90, 5);
                break;
            case "Fractal Plant":
                system.setRule('F', "FF");
                system.setRule('X', "F+[[X]-X]-F[-FbX]+X");
                system.setAxiom("--X");
                system.setValues(10, 200, 200, 0, 25, 5);
                break;
            case "Fractal Bush":
                system.setRule('X', "X[-FFF][+FFF]FX");
                system.setRule('Y', "YFX[+Y][-Y]");
                system.setAxiom("Y");
                system.setValues(20, init_x, init_y*1.9, -90, 25.7, 5);
                break;
            case "Fractal Windy Bush":
                system.setRule('F', "FF+[+F-F-F]-[-F+F+F]");
                system.setAxiom("F");
                system.setValues(20, init_x/2, init_y*1.75, -90, 22.5, 3);
                break;
            case "Gosper":
                system.setRule('X', "XFX-YF-YF+FX+FX-YF-YFFX+YF+FXFXYF-FX+YF+FXFX+YF-FXYF-YF-FX+FX+YFYF-");
                system.setRule('Y', "+FXFX-YF-YF+FX+FXYF+FX-YFYF-FX-YF+FXYFYF-FX-YFFX+FX+YF-YF-FX+FX+YFY");
                system.setAxiom("-YF");
                system.setValues(15, init_x, init_y*1.2, 0, 90, 2);
                break;
            case "Crystal":
                system.setRule('F', "FF+F++F+F");
                system.setAxiom("F+F+F+F"); // 0,0?
                system.setValues(7, init_x, init_y, 0, 90, 5);
                break;
            default:
                break;
        }

        // SET UP BEFORE THIS
        system.setUpSystem();
        invalidate();
    }

    public void setSystemColor(int color){
        if (system != null){
            color_chosen = color;
        }
    }

    // Draw L-System!
    public void drawSystem(){
        // pass to DrawingView
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh){
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
    }

    @Override
    public void onDraw(Canvas canvas){
        super.onDraw(canvas);
        // Execute the instructions!
        if (system != null){
            system.setCanvas(canvas);
            system.runInstructions();
        }
    }

    public Bitmap getBitmap(){
        Bitmap saved = Bitmap.createBitmap(this.viewWidth, this.viewHeight,ARGB_8888);
        Canvas canvas = new Canvas(saved);
        if (system != null){
            system.setCanvas(canvas);
            system.runInstructions();
        }
        return saved;
    }
}
