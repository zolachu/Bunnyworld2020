package edu.stanford.cs108.bunnyworld;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class GameListActivity extends AppCompatActivity {
    private BunnyWorldData data;
    private SQLiteDatabase db;
    private Cursor cursor;
    protected String[] fromArray = {"name", "gameid"};
    protected int[] toArray = {android.R.id.text1, android.R.id.text2};

    SimpleCursorAdapter gamesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        data = BunnyWorldData.getInstance();
        db = data.getDb();
        setTitle(R.string.game_list_title);
        setContentView(R.layout.list_view_layout);

        ListView listView = findViewById(R.id.list_view);
        listView.setEmptyView(findViewById(R.id.empty));

        cursor = getGamesCursor();

        if (cursor.getCount() != 0) {
            gamesAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, cursor, fromArray, toArray, 0);
            listView.setAdapter(gamesAdapter);

            listView.setOnItemClickListener((parent, view, position, viewId) -> {
                cursor = gamesAdapter.getCursor();
                cursor.moveToPosition(position);
                int gameId = cursor.getInt(cursor.getColumnIndex("gameid"));
                Game game = data.findGame(gameId);
                data.setSelectedGame(game);
                data.clearValidationErrorMessage(); // Clear any lingering validation error message

                Intent intent = new Intent(
                        getApplicationContext(),
                        data.isEditMode() ? GameEditActivity.class : GamePlayActivity.class
                );

                // If game data structures are invalid it is unplayable.
                // The data singleton may contain an error message to be presented in the dialog
                if (!data.isEditMode() && !game.isValid()) {
                    invalidGameDialog();
                    return;
                }

                startActivity(intent);
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(
                data.isEditMode() ? R.menu.game_list_menu : R.menu.game_play_menu, menu
        );

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.back){
            goBack();
        }
        if (id == R.id.new_game) {
            newGameDialog();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        gamesAdapter.changeCursorAndColumns(getGamesCursor(), fromArray, toArray);
        gamesAdapter.notifyDataSetChanged();
    }

    private void invalidGameDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setCancelable(true);
        builder.setMessage(
                getString(R.string.game_invalid_message) + "\n" + data.getValidationErrorMessage()
        );
        builder.setTitle(R.string.game_invalid_title);
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void newGameDialog() {
        final View nameLayout = getLayoutInflater().inflate(R.layout.dialog_name_edit, null);
        final EditText editText = nameLayout.findViewById(R.id.name_edit);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.game_new);
        builder.setCancelable(true);
        builder.setView(nameLayout);
        // Set a positive button but then override it so we can validate input without dismissing
        builder.setPositiveButton(R.string.save_btn, (dialog, which) -> {});

        final AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = editText.getText().toString();
            if (name.isEmpty() || !data.isUniqueGameName(name)) {
                editText.setError(getString(R.string.name_edit_unique));
                return;
            }

            Game game = data.createGame(name);
            data.setSelectedGame(game);

            Intent intent = new Intent(getApplicationContext(), GameEditActivity.class);
            startActivity(intent);
            dialog.dismiss();
        });
    }

    private Cursor getGamesCursor() {
        return db.rawQuery("SELECT * FROM games;", null);
    }

    public void goBack(){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}
