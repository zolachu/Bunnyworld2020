package edu.stanford.cs108.bunnyworld;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;

public class BunnyWorldData {
    public static final String DB_NAME = "BunnyWorldDB";
    private static final BunnyWorldData ourInstance = new BunnyWorldData();

    public static BunnyWorldData getInstance() {
        return ourInstance;
    }

    private SQLiteDatabase db;
    private boolean editMode = false;
    private File exportFile;
    private Game selectedGame;
    private Page selectedPage;
    private Shape selectedShape;
    private String validationErrorMessage;
    private Shape copiedShape;

    private BunnyWorldData() {
        selectedGame = null;
        selectedPage = null;
        selectedShape = null;
        copiedShape = null;
        validationErrorMessage = "";
    }

    public SQLiteDatabase getDb() {
        return this.db;
    }

    public boolean isEditMode() {
        return editMode;
    }

    public void setEditMode(boolean editMode) {
        this.editMode = editMode;
    }

    public void setDb(SQLiteDatabase db) {
        this.db = db;
    }

    public void setCopiedShape(Shape shape) {
        copiedShape = shape;
    }

    public Shape getCopiedShape() {
        return copiedShape;
    }

    public int findMaxID() {
        String maxID = "SELECT * FROM games";
        Cursor cursor = db.rawQuery(maxID, null);

        int temp = cursor.getCount();
        if (temp <= 0) {
            //if it can't find the maxID then it returns 0
            return 0;
        }
        cursor.moveToLast();
        int maxIntID = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
        return maxIntID;
    }

    public Game createGame(String name) {
        int newId = this.findMaxID() + 1;

        Game game = new Game(
                newId,
                name,
                new ArrayList<>(Collections.singletonList(new Page()))
        );

        String newGameStr = "INSERT INTO games VALUES "
                + "(\'"+ game.getName()+"\',\'" + game.toJSON() + "\'," +game.getId()+",NULL);";
        db.execSQL(newGameStr);

        return game;
    }

    public void deleteGame(int id) {
        String deleteStr = "DELETE FROM games WHERE gameid = " + id + ";";
        db.execSQL(deleteStr);
    }

    public void deleteAll() {
        String deleteStr = "DELETE FROM games;";
        db.execSQL(deleteStr);
    }

    public Game findGame(int id) {
        String findStr = "SELECT * FROM games" + " WHERE gameid = " + id + ";";
        Cursor cursor = db.rawQuery(findStr, null);

        if (cursor.getCount() == 0 ) {
            return null;
        }

        //In theory there should only be one game with that id so we don't need to worry about
        //iterating through them. Assumptions: Id is valid and links to valid game
        cursor.moveToFirst();
        int index = cursor.getColumnIndexOrThrow("game");

        String nxtGame = cursor.getString(index);

        Game game = Game.JSONtoGame(nxtGame);

        return game;
    }

    public Game findGame(String name) {
        String findStr = "SELECT * FROM games WHERE name = '" + name + "' COLLATE NOCASE;";
        Cursor cursor = db.rawQuery(findStr, null);

        if (cursor.getCount() == 0 ) {
            cursor.close();
            return null;
        }

        cursor.moveToFirst();
        int index = cursor.getColumnIndexOrThrow("game");
        String nxtGame = cursor.getString(index);
        cursor.close();

        return Game.JSONtoGame(nxtGame);
    }

    //This is a general case that can be used for anything as long as the game is updated beforehand
    //The other methods are technically not necessary but they exist to make the rest of the code
    //work temporarily
    public Game updateGame(Game game) {
        if (game != null) {
            String updateName = "UPDATE games SET name = \'" + game.getName() + "\'," +
                    " game = \'" + game.toJSON() + "\' WHERE gameid = " + game.getId() + ";";
            db.execSQL(updateName);
        }

        return game;
    }

    public File writeGameToFile(String path, Game game) throws Exception{
        String JsonStr = game.toJSON();

        try {
            File file = new File(path,  game.getName() + ".json");
            file.createNewFile();
            Writer output = new BufferedWriter(new FileWriter(file));
            output.write(JsonStr);
            output.close();
            return file;
        } catch (Exception e) {
            throw e;
        }
    }

    public Game importGameFromFile(String jsonFile) {
        if (jsonFile.isEmpty()) {
            return null;
        }

        Game game = Game.JSONtoGame(jsonFile);

        if (findGame(game.getId()) != null) {
            int newId = this.findMaxID() + 1;
            game = Game.JSONtoGame(newId, jsonFile);
        }

        String name = game.getName();
        if (!isUniqueGameName(name)) {
            int i = 1;
            while (!isUniqueGameName(game.getName())) {
                game.setName(name + "(" + i + ")");
                i++;
            }
        }

        String newGameStr = "INSERT INTO games VALUES "
                + "(\'"+ game.getName()+"\',\'" + game.toJSON() + "\'," +game.getId()+",NULL);";
        db.execSQL(newGameStr);

        return game;
    }

    /**
     * Indicates if the given game name is unique.
     * @param name game name
     * @return true if given name is unique, otherwise false
     */
    public boolean isUniqueGameName(String name) {
        if (name == null || db == null) return false;

        return findGame(name) == null;
    }

    /**
     * Indicates if the given game name is unique, ignoring a record with the same ID.
     * Used to when renaming a game to determine if any other games in the DB already have the same
     * name.
     * @param gameId id of game
     * @param name game name
     * @return true if given name is unique, otherwise false
     */
    public boolean isUniqueGameName(int gameId, String name) {
        if (name == null || db == null) return false;

        Game game = findGame(name);
        return game == null || game.getId() == gameId;
    }

    public Game getSelectedGame() {
        return this.selectedGame;
    }

    public void setSelectedGame(Game game) {
        this.selectedGame = game;
    }

    public void setSelectedPage(Page page) {
        this.selectedPage = page;
    }

    public Page getSelectedPage() {
        return selectedPage;
    }

    public Shape getSelectedShape() {
        return selectedShape;
    }

    public void setSelectedShape(Shape shape) {
        this.selectedShape = shape;
    }

    public void clearValidationErrorMessage() {
        setValidationErrorMessage("");
    }

    public String getValidationErrorMessage() {
        return validationErrorMessage;
    }

    public void setValidationErrorMessage(String message) {
        validationErrorMessage = String.valueOf(message);
    }

    public File getExportFile() { return this.exportFile; }

    public void setExportFile(File file) { this.exportFile = file;}
}
