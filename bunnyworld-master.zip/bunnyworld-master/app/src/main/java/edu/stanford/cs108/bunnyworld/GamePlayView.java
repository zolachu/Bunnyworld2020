package edu.stanford.cs108.bunnyworld;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.math.MathUtils;

public class GamePlayView extends View {
    public static final float PAGE_AREA_HEIGHT_RATIO = 0.75f;
    private static final int INVENTORY_DIVIDER_STROKE_WIDTH = 5;
    private static final int DIVIDER_PADDING = 10;
    private final BunnyWorldData data = BunnyWorldData.getInstance();
    private int width, height, inventory_area_y;
    private Game game;
    private Paint dividerStroke;
    private Paint highlightedDividerStroke;
    private Page currentPage;
    private Shape selectedShape;
    private float touchX, touchY;
    private Paint[] separators;
    private Paint[] highlightedSeparators;
    private int numMovableShapes;
    private int sepIndex;
    private float ratio;
    private float shrink_height;
    private float shrink_width;

    public GamePlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        game = data.getSelectedGame();
        currentPage = game.getStartPage();
        // selectedPage can change at run time due to shape script goto actions
        data.setSelectedPage(currentPage);
        // Ensure no old state from editor
        data.setSelectedShape(null);
        numMovableShapes = currentPage.getNumShapes();

        dividerStroke = new Paint();
        dividerStroke.setColor(Color.BLACK);
        dividerStroke.setStyle(Paint.Style.STROKE);
        dividerStroke.setStrokeWidth(INVENTORY_DIVIDER_STROKE_WIDTH);

        highlightedDividerStroke = new Paint(dividerStroke);
        highlightedDividerStroke.setColor(Color.GREEN);

        separators = new Paint[numMovableShapes + 1];
        highlightedSeparators = new Paint[numMovableShapes + 1];
        for (int i = 0; i < numMovableShapes + 1; i++) {
            separators[i] = new Paint();
            separators[i].setColor(Color.BLACK);
            separators[i].setStyle(Paint.Style.STROKE);
            separators[i].setStrokeWidth(INVENTORY_DIVIDER_STROKE_WIDTH);

            highlightedSeparators[i] = new Paint(separators[i]);
            highlightedSeparators[i].setColor(Color.GREEN);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        width = w;
        height = h;
        inventory_area_y = (int) (height * PAGE_AREA_HEIGHT_RATIO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Update currentPage if selectedPage has changed. The selectedPage reference may be changed
        // by shape script goto actions.
        if (data.getSelectedPage() != null && !data.getSelectedPage().equals(currentPage)) {
            currentPage = data.getSelectedPage();
            currentPage.onEnter(game, getContext());
            invalidate(); // Redraw in case onEnter action changes selectedPage with goto action
        }

        int color = currentPage.getColor();
        currentPage.setBackgroundFill(color);

        currentPage.draw(canvas, getContext());

        ratio = ((float) width)/numMovableShapes;

        // Draw inventory divider with highlight color, indicating page shapes can be dropped here
        canvas.drawLine(0, inventory_area_y, width, inventory_area_y, selectedShape != null &&
                !selectedShape.getInInventory() ? highlightedDividerStroke : dividerStroke
        );
        if (selectedShape != null) {
            for (int i = 0; i < numMovableShapes + 1; i++) {
            canvas.drawLine(i * ratio, inventory_area_y, i * ratio, height, selectedShape != null &&
                    !selectedShape.getInInventory() && (i == sepIndex || i == sepIndex + 1) ? highlightedSeparators[i] : separators[i]);
            }
        } else {
            for (int i = 0; i < numMovableShapes + 1; i++) {
                canvas.drawLine(i * ratio, inventory_area_y, i * ratio, height, separators[i]);
            }
        }

        // Draw inventory last so shapes appears on top of any hovered page shapes
        game.drawInventory(canvas, getContext());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touchX = event.getX();
                touchY = event.getY();

                selectedShape = getVisibleShapeAt(touchX, touchY);
                if (selectedShape == null) break;

                shrink_height = selectedShape.getHeight();
                shrink_width = selectedShape.getWidth();

                // User selected a selectable shape, keep a copy of its coordinates
                touchX = selectedShape.getX();
                touchY = selectedShape.getY();
                // If selected shape is in possessions area, highlight other shapes that have an
                // appropriate onDrop script
                if (selectedShape.getInInventory()) {
                    currentPage.highlightShapesWithOnDrop(selectedShape);
                    game.highlightInventoryItemsWithOnDrop(selectedShape);
                } else {
                    // Selected shape is a page shape, call its onClick actions.
                    // This may change selectedPage in data singleton if a goto <page> action is run
                    game.onClickShape(selectedShape, getContext());
                    invalidate();
                }

                break;
            case MotionEvent.ACTION_MOVE:
                if (selectedShape == null || !selectedShape.isMovable()) break;

                float y = event.getY();
                // Center the shape on touch coordinates and ensure it can only be moved within
                // display boundary.
                selectedShape.setX(MathUtils.clamp(
                        event.getX() - selectedShape.getWidth() / 2,
                        0,
                        width - selectedShape.getWidth()
                ));

                // "Snap" page shapes to inventory area when they cross area boundary
                if (!selectedShape.getInInventory()
                        && y + selectedShape.getHeight() / 2 > inventory_area_y) {
                    sepIndex = (int) (event.getX() / ratio);
                    selectedShape.setX((int)(event.getX() / ratio) * ratio + DIVIDER_PADDING);
                    selectedShape.setY(inventory_area_y + DIVIDER_PADDING);
                    float shrinkage = Math.max(shrink_width/ratio, shrink_height/(height - inventory_area_y));
                    shrinkage = Math.max(shrinkage, 1);
//                    selectedShape.setHeight(shrink_height / shrinkage);
//                    selectedShape.setWidth(shrink_width / shrinkage);
                } else if (selectedShape.getInInventory()
                        && y - selectedShape.getHeight() / 2 - DIVIDER_PADDING <= inventory_area_y
                        && y + selectedShape.getHeight() >= inventory_area_y) {
                    // "Snap" inventory items to page area when they cross area boundary
//                    selectedShape.setHeight(shrink_height);
//                    selectedShape.setWidth(shrink_width);
//                    selectedShape.setX(event.getX() * ratio + DIVIDER_PADDING);
                    //selectedShape.setX(event.getX());
//                    selectedShape.setX((int) (event.getX() / ratio) * ratio + DIVIDER_PADDING);
                    selectedShape.setY(inventory_area_y - selectedShape.getHeight() - DIVIDER_PADDING);
                } else {
                    sepIndex = (int)(selectedShape.getX() / ratio);
                    selectedShape.setY(MathUtils.clamp(
                            y - selectedShape.getHeight() / 2,
                            0,
                            height - selectedShape.getHeight()
                    ));
                    if (y - selectedShape.getHeight() / 2 - DIVIDER_PADDING > inventory_area_y) {
                        sepIndex = (int) (event.getX() / ratio);
                        selectedShape.setX((int) (event.getX() / ratio) * ratio + DIVIDER_PADDING);
                        selectedShape.setY(inventory_area_y + DIVIDER_PADDING);
                    } else {
                        selectedShape.setX(event.getX());
                    }

             //        selectedShape.setX(event.getX() * ratio + DIVIDER_PADDING);
//                    float shrinkage = Math.max(shrink_width/ratio, shrink_height/(height - inventory_area_y));
//                    shrinkage = Math.max(shrinkage, 1);
//                    selectedShape.setHeight(shrink_height / shrinkage);
//                    selectedShape.setWidth(shrink_width / shrinkage);
                }

                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                if (selectedShape == null) break;

                currentPage.setShapesHovered(false); // Remove highlight from page shapes
                game.setShapesHovered(false); // Remove highlight from inventory shapes

                // Shape was moved from inventory area to page
                if (selectedShape.getInInventory() && selectedShape.getY() <= inventory_area_y) {
                    // Check if selectedShape was not dropped on a shape, add to page normally
                    // if this is the case
                    String check = onShape(selectedShape.getX(), selectedShape.getY(), selectedShape.getName());
                    switch (check) {
                        case "notOnShape":
                            currentPage.addShape(selectedShape);
                            game.removeInventoryItem(selectedShape);
                            selectedShape.setInInventory(false);
                            break;
                        case "bad":
                            //Check if selectedShape was dropped on page shape without corresponding
                            // onDrop, "snap back" if this is the case
                            selectedShape.setX(touchX);
                            selectedShape.setY(touchY);
                            break;
                        case "good":
                            // Check if selectedShape was dropped on an appropriate page shape and
                            //  call its onDrop method if this is the case
                            Shape dropOnShape = currentPage.getUniqueShapeAt(
                                    selectedShape.getX(),
                                    selectedShape.getY(),
                                    selectedShape.getName()
                            );
                            currentPage.addShape(selectedShape);
                            selectedShape.setWidth(shrink_width);
                            selectedShape.setHeight(shrink_height);
                            game.removeInventoryItem(selectedShape);
                            selectedShape.setInInventory(false);
                            if (dropOnShape != null) dropOnShape.onDrop(selectedShape.getName(), game, getContext());
                            break;
                    }
                } else if (!selectedShape.getInInventory()) {
                    if (selectedShape.getY() > inventory_area_y) {
                        // Shape was moved from page area to inventory
                        game.addInventoryItem(selectedShape);
                        selectedShape.setInInventory(true);
                        currentPage.removeShape(selectedShape);
                    } else {
                        //page shape moved on page

                        //if selected shape on page dropped on another page shape with corresponding
                        // onDrop, call that shape's onDrop
                        String check = onShape(
                                selectedShape.getX(),
                                selectedShape.getY(),
                                selectedShape.getName()
                        );
                        switch (check) {
                            case "good":
                                Shape dropOnShape = currentPage.getUniqueShapeAt(
                                        selectedShape.getX(),
                                        selectedShape.getY(),
                                        selectedShape.getName()
                                );
                                if (dropOnShape == null) break;

                                dropOnShape.onDrop(selectedShape.getName(), game, getContext());
                                break;
                            case "bad":
                                //if selected shape on page dropped on another page shape without
                                // corresponding onDrop, return to original location
                                selectedShape.setX(touchX);
                                selectedShape.setY(touchY);
                                break;
                        }
                    }
                }

                selectedShape = null;
                invalidate();
                break;
        }

        return true;
    }

    //returns "notOnShape" if there is no unique page shape at the given coordinates,
    //returns "good" if selected shape is dropped on page shape with
    //matching onDrop, and returns "bad" if selected shape
    //dropped on page shape without corresponding onDrop
    private String onShape(float x, float y, String dropped_name) {
        Shape shape = currentPage.getUniqueShapeAt(x, y, dropped_name);
        if (shape == null) return "notOnShape";

        return (shape.inOnDrop(dropped_name)) ? "good" : "bad";
    }

    /**
     * Returns a selectable and non-hidden shape at the given coordinates, if one exists.
     * First checks game inventory and then the current page. If no shapes are found at given
     * coordinates then null is returned.
     * @param x horizontal coordinate
     * @param y vertical coordinate
     * @return a shape if found, otherwise null
     */
    private Shape getVisibleShapeAt(float x, float y) {
        Shape shape = game.getInventoryItemAt(x, y);
        if (shape == null) shape = currentPage.getSelectableShapeAt(x, y);

        if (shape == null || shape.getHidden()) return null;

        return shape;
    }
}
