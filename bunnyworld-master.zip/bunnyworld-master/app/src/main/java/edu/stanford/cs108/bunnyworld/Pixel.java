package edu.stanford.cs108.bunnyworld;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class Pixel {
    float x;
    float y;

    float size;

    Paint curr_paint;

    public Pixel(float x_pos, float y_pos, float size_ini,  int color){ // public or private?
        // By default is white
        curr_paint = new Paint();
        curr_paint.setStyle(Paint.Style.FILL);
        // Change paint color
        curr_paint.setColor(color);

        x = x_pos;
        y = y_pos;

        size = size_ini;
    }

    public void setColor(int color){
        // Change color
        curr_paint.setColor(color);
    }

    // Takes a canvas and a color
    public void draw(Canvas init_canvas){
        // Draw the pixel
        RectF rect = new RectF(x, y, x + size, y + size);
        init_canvas.drawRect(rect, curr_paint);
    }

    public boolean insidePixel(float sel_x, float sel_y){
        if (sel_x >=  x && sel_x <= (x + size) && sel_y >= y && sel_y <= (y + size)){
            return true;
        } else {
            return false;
        }
    }
}
