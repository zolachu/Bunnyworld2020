package edu.stanford.cs108.bunnyworld;

import android.graphics.Color;
import android.graphics.Paint;
import android.util.TypedValue;

import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class ResourceList {
    private static final ResourceList ourInstance = new ResourceList();

    static ResourceList getInstance() {
        return ourInstance;
    }

    private String path;

    // Initialize list of default image/sound names
    private List<String> resource_images = Stream.of(
            "carrot",
            "carrot2",
            "death",
            "duck",
            "fire",
            "mystic"
    ).collect(Collectors.toList());
    private List<String> sounds = Stream.of(
            "carrotcarrotcarrot",
            "evillaugh",
            "fire",
            "hooray",
            "munch",
            "munching",
            "woof"
    ).collect(Collectors.toList());

    private ArrayList<String> user_images = new ArrayList<>();

    // Constructor
    private ResourceList() {

    }
    // used to check if image name is unique
    public boolean checkUnique(String name){
        if (resource_images.contains(name)){
            return false;
        } else if (user_images.contains(name)){
            return false;
        } else{
            return true;
        }
    }

    // Returns true if local image, false if resource image
    // Doesn't allow for possibility that name doesn't exist atm TODO
    public boolean checkLocal(String name){
        if (resource_images.contains(name)){
            return false;
        } else {
            return true;
        }
    }

    // Functions for saving/loading images
    public void setPath(String ini_path){
        path = ini_path;
    }

    public String getPath(){
        return path;
    }

    public List<String> getResourceImgNames() { return resource_images; }

    private List<String> getListFiles2(File parentDir) {
        List<String> inFiles = new ArrayList<>();
        Queue<File> files = new LinkedList<>();
        files.addAll(Arrays.asList(parentDir.listFiles()));
        while (!files.isEmpty()) {
            File file = files.remove();
            if (file.isDirectory()) {
                files.addAll(Arrays.asList(file.listFiles()));
            } else if (file.getName().endsWith(".jpg")) {
                String file_name = file.getName();
                file_name = file_name.replace(".jpg", "");
                inFiles.add(file_name);
            }
        }
        return inFiles;
    }

    public void addUserImage(String name){
        this.updateUserImages();
        if (!user_images.contains(name)){
            user_images.add(name);
        }
    }

    public String[] getResourceImages(){
        String[] image_arr = new String[resource_images.size()];
        image_arr = resource_images.toArray(image_arr);
        return image_arr;
    }

    public String[] getUserImages(){
        String[] image_arr = new String[user_images.size()];
        image_arr = user_images.toArray(image_arr);
        return image_arr;
    }

    public String[] getImages(){
        this.updateUserImages();
        // Create list of user and resource imagers
        List<String> images = new ArrayList<>();
        // Add resource and user images
        images.addAll(user_images);
        images.addAll(resource_images);

        // Create array with complete list of images
        String[] image_arr = new String[images.size()];
        image_arr = images.toArray(image_arr);
        return image_arr;
    }

    public String[] getSounds(){
        String[] sound_arr = new String[sounds.size()];
        sound_arr = resource_images.toArray(sound_arr);
        return sound_arr;
    }

    private void updateUserImages(){
        if (path != null){
            File root = new File(path);
            List<String> existing = getListFiles2(root);
            // Update names
            for (String existing_name : existing){
                if (!user_images.contains(existing_name)){
                    user_images.add(existing_name);
                }
            }
        }
    }

    public boolean hasImage(String name) {
        if (resource_images.contains(name) || user_images.contains(name)){
            return true;
        } else {
            return false;
        }
    }

    public boolean hasSound(String name) {
        return sounds.contains(name);
    }

    public void addImage(String image_name){
        resource_images.add(image_name);
    }
    public void addSound(String sound_name){
        sounds.add(sound_name);
    }

    // ZOLA extension -- rich text support
    public static Paint paintBig() {
        Paint paint = getBasePaint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(8);
        return paint;
    }
    public static Paint paint() {
        Paint paint = getBasePaint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(1);
        paint.setTextSize(30);
        return paint;
    }

    public static Paint paintText() {
        Paint paint = getBasePaint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(1);
        paint.setTextSize(30);
        paint.setStyle(Paint.Style.FILL);
        return paint;
    }

    public static Paint paintLight() {
        Paint paint = getBasePaint();
        paint.setColor(Color.GRAY);
        paint.setStrokeWidth(1);
        paint.setAlpha(128);
        paint.setTextSize(30);
        return paint;
    }

    public static Paint paintBox() {
        Paint paint = getBasePaint();
        paint.setColor(Color.BLUE);
        paint.setAlpha(128);
        paint.setStrokeWidth(1);
        paint.setTextSize(30);
        return paint;
    }

    public static Paint paintRed() {
        Paint paint = getBasePaint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(4);
        paint.setAlpha(128);
        paint.setTextSize(30);
        return paint;
    }
    public static Paint paintRedLine() {
        Paint paint = getBasePaint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(5);
        paint.setAlpha(128);
        paint.setTextSize(30);
        return paint;
    }

    public static Paint getBasePaint() {
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.isAntiAlias();
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(30);
        return paint;
    }

}
